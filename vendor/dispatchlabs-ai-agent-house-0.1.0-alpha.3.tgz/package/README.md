# Agent House

Create agents, give them their own identities, and work with them across applications and AI harnesses.

Agent House is designed as a headless backend with CLI, web, desktop and mobile frontends. Shared application services own behavior and permissions; the CLI is the first interface. The CLI now calls the [local application service](docs/application.md). Independent agent administration also has an HTTP frontend; native execution also has shared CLI/HTTP operations; MCP bindings remain planned. See the [backend boundary](docs/architecture.md#shared-backend-and-thin-interfaces).

**Status: runnable source alpha.** The CLI validates YAML/JSON definitions and runs Codex, Claude, or Pi with an existing Agent Wiki machine credential. Agent House also supplies an embeddable identity/grant module and at-most-once job admission. An independent identity service provides shared CLI/HTTP administration and authorized native execution through its own SQLite database; there is no published package. See [authority setup and limits](docs/authority.md).

An agent definition uses `default_harness` to select from its `harnesses` map. It captures its name, instructions, principal, default harness, model, and thinking level. Credentials and grants are managed separately by authorized services. Codex, Claude, and Pi are the intended execution targets; switching harnesses should preserve the agent's identity while validating the selected runtime settings.

## Try the CLI

Requires Node.js 24.19 or newer. From a checkout:

```sh
npm ci
node bin/agent-house.mjs validate examples/wiki-editor.yaml --json
```

This returns `valid: true` and a stable definition hash without needing credentials. To run an agent, copy the example, set its principal and connection file, and use:

```sh
node bin/agent-house.mjs run /path/to/wiki-editor.yaml "Read the guide and summarize it" --json
```

See the [CLI guide](docs/cli.md) for credential prerequisites, outputs, side effects, and unattended invocation. Codex must already be installed and authenticated. The first tested combination is Linux, Codex 0.154.0, and `gpt-6-astra` with `low` thinking. macOS is not yet verified.

An AI agent with shell and file access can follow the same guide: “Read `docs/cli.md` in this checkout, install dependencies, and validate the example. If an enrolled wiki connection is available, run a read-only task and verify its run receipt.” This delegation prompt has not been separately qualified as an onboarding flow.

## Intended uses

- Research incoming email before a person opens it.
- Run multiple wiki editors that verify and correct mistakes.
- Review repositories and produce demonstrated findings or tested fixes.
- Analyze agent traces and propose improvements to instructions and skills.

## Boundaries

Agent House owns the shared agent identity, immutable definition, ownership, and invocation/configuration grant implementation. The wiki adapter embeds that module in its existing control database and retains login, resource grants, OAuth credentials and run authorization. Applications enforce access to their resources. See [the identity boundary](docs/identity.md).

Ten workers can be ten runs of one agent, each with distinct attribution and work state. They do not require ten permanent agent principals.

See the [architecture](docs/architecture.md), [implementation plan](docs/implementation-plan.md), and [verification record](docs/verification.md) for implemented behavior and remaining work.

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). Proposals should preserve the distinction between definitions, authorization, and execution. Implementation claims require tests against the named harness and version.

Created by Chris Reynolds, cofounder of Dispatch Labs AI. Licensed under the [MIT License](LICENSE).
