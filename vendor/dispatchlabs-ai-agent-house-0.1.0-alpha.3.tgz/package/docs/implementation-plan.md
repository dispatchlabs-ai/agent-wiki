# Implementation plan

The first CLI slice is implemented: strict version 2 YAML/JSON validation, Codex execution, private run records, noninteractive tool access through an enrolled wiki credential, and run closure. See [verification](verification.md). This does not migrate the wiki identity store or deploy a service. The broader acceptance criteria below remain open.

Follow-up: Claude/Pi harness configurations and native adapters are qualified for synthetic
reads; shared identity/control grants are extracted into the embedded Agent House
module; `job` adds persistent at-most-once occurrence admission and overlap refusal.
The private deployment uses one native daily heartbeat. The broader service,
resume, lifecycle and scale acceptance criteria below remain open.

## Current milestone: one application backend, two interfaces

First slice implemented: the CLI now calls `definition.validate`, `run.start`,
and `job.execute` through the [local application service](application.md).
Request checks, harness selection and timeout defaults are shared; the operation
catalog records CLI coverage and absent HTTP/MCP bindings. Direct-call tests
cover malformed requests, replay and the existing credential authorization path.
The [independent authority](authority.md) now adds bearer-authenticated human
principals, agent administration, revision checks and retry receipts through CLI,
HTTP and direct calls. Native execution now uses its own admission ledger,
registered resource bindings and current authorization checks. `invoke` and HTTP
share `run.start`/`run.get`; jobs add occurrence and overlap enforcement. The real
Wiki Auditor has moved to this path with its existing principal/owner and history.
Service principals, OIDC, resource federation and MCP parity remain outstanding.

Before adding independent administration commands, establish the
[shared backend boundary](architecture.md#shared-backend-and-thin-interfaces).
CLI, HTTP and MCP are adapters over the same authorized operations; the planned
Agent House web UI consumes that backend. Do not build workflow logic into CLI
handlers or make a web server execute CLI commands.

1. Inventory definition, identity/grant, run and job operations, with explicit
   interface coverage and outstanding authentication/lifecycle gaps.
2. Introduce shared request/result/error contracts and trusted caller context.
   Route current CLI operations through that boundary; retain native adapters
   and existing run receipts. Keep local operation possible without a daemon.
3. Give the backend independent state and authentication integration. Implement
   agent creation, definition updates and invocation grants once in services;
   expose them through CLI and a versioned HTTP API, followed by MCP parity.
4. Prove the same synthetic create → grant → invoke → inspect flow through CLI
   and HTTP with Agent Wiki stopped. Verify denial through both interfaces and
   direct service calls, revocation, stale revisions and duplicate requests.
5. Connect an agent to Agent Wiki through its separately authorized resource
   adapter. Reuse Agent Bridge's UI/gateways against the shared services, then
   qualify persistent conversations and unattended lifecycle behavior.

Completion requires equivalent state, permissions and receipts across interfaces,
not matching command names. Administrative capabilities belong in the same
catalog with explicit permissions. Administration and native run integration
through CLI/HTTP are implemented; the UI, resume and durable supervision remain
open. The wiki resource adapter still owns its independent credential lifecycle.

## 1. Establish the portable definition contract

Design a minimal versioned schema, synthetic examples, and strict validation. Compare a small native adapter layer with existing Open Agent Specification and Agent Controller capabilities. Specify principal references, version updates, instruction placement, model profiles, and errors for unsupported settings.

Acceptance: the same definition can be resolved for the three intended harnesses, with explicit failures for unsupported combinations and no self-granted privileges.

## 2. Extract the identity and authorization foundation

Inspect the existing Agent Wiki principal, definition, grant, credential, and remote-authorization implementation and tests. Separate generic policy from wiki-specific content permissions. Preserve stable IDs, ownership, approved definition versions, revocation, and historical attribution.

Define a supported integration boundary before moving code. Verify the source license and retain attribution. Keep the working wiki connection available throughout a deliberate cutover; do not create duplicate authoritative identity stores accidentally.

Acceptance: human and service invocation, denied access, suspension, revocation, and immutable definition versions pass through the extracted boundary. A synthetic second application demonstrates that the model is not wiki-specific.

## 3. Connect native execution

Integrate a native conversation backend, starting with existing Agent Bridge capabilities where suitable. Qualify Codex, Claude, and Pi separately. Preserve session identity and attach every execution to its actor, initiator and definition version.

Acceptance: real synthetic tool calls demonstrate instruction loading, selected model/thinking, access controls, results, cancellation and resume in each harness. A connection indicator alone is insufficient.

## 4. Add unattended jobs

Define an authenticated launch contract usable by timers, event handlers and humans. Add durable job occurrences, run IDs, work leases, budgets, retries and receipts. Reuse existing headless compute controls for optional remote execution.

Acceptance: duplicate triggers, token expiry, restart after a write, unavailable dependencies, cancellation and ambiguous launch outcomes are handled without silent duplicate effects or replacement sessions.

## 5. Pilot and scale

Start with email pre-research and one wiki editor. Scale wiki concurrency to two and then ten workers, explicitly testing write conflicts, distinct attribution, and individual revocation. Add repository and trace exploration after the lifecycle is reliable.

Measure useful verified outcomes, false positives, duplication, cost and regressions. Do not use edit count as the success metric.
