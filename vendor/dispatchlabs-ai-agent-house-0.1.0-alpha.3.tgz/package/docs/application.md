# Local application services

`@dispatchlabs-ai/agent-house/application` exports `createApplication`,
`ApplicationError`, and the `operations` catalog. This source-alpha interface
is a shared local application entry point, not a network authorization boundary.

```js
import { createApplication } from "@dispatchlabs-ai/agent-house/application";

const application = createApplication();
const result = await application.execute("definition.validate", {
  definition: "/path/to/agent.yaml",
  harness: "pi",
});
```

## Operation contract

| Operation             | Required input                              | Optional input                          | Result                                                               |
| --------------------- | ------------------------------------------- | --------------------------------------- | -------------------------------------------------------------------- |
| `definition.validate` | `definition`                                | `harness`                               | Identity, definition hash, configured harnesses and resolved runtime |
| `run.start`           | `definition`, `task`                        | `harness`, `cwd`, `stateDir`, `timeout` | Existing attributed run receipt                                      |
| `job.execute`         | `definition`, `task`, `jobId`, `occurrence` | Same as run                             | Run receipt plus `replayed`                                          |

The default definition repository loads local YAML/JSON paths. The host may
supply a `definitions.load(reference)` repository and an `executeRun` adapter.
These dependencies and `jobStateDir` are host configuration, never request
fields. No operation permits a request to supply an actor, credentials, grants,
or an executor. A default timeout of 300 seconds and the maximum of 86400 seconds
are enforced by services, including for direct callers. Unknown fields and missing
job identity are rejected before loading definitions or creating job state.

`ApplicationError.code` identifies `UNKNOWN_OPERATION`, `INVALID_REQUEST`, and
`INVALID_DEFINITION`. Execution outcomes retain existing receipt statuses;
underlying execution and job-conflict exceptions retain their existing messages.
A complete cross-transport error taxonomy remains outstanding. CLI JSON errors
retain `error` and add `code` when available; CLI exit codes remain unchanged.

Job receipts, overlap refusal and at-most-once occurrence admission reuse the
existing durable implementation. A replay does not execute another model call.
This boundary does not add restart recovery or background worker supervision.

## Authority and interface coverage

Execution still requires the enrolled Agent Wiki credential. The native backend
checks credential-to-principal binding and obtains authoritative run admission
before exposing tools or starting the harness. The application layer does not
create independent human/service authentication, and a trusted host replacing
its execution dependency is responsible for retaining those checks.

Only CLI bindings exist for this legacy filesystem API; the catalog explicitly marks HTTP and MCP absent.
Do not expose this local request object directly over a network: it accepts local
paths and returns private run locations. Hosted adapters need authenticated caller
context, shared authorization, registered resource IDs, safe result projection,
and independent identity/state ownership before they can serve other users.

Tests compare CLI/direct validation across all three harnesses, reject malformed
and actor/executor-injection requests, preserve job replay without duplicate
execution, and verify revoked credentials through the application entry point
against a synthetic wiki. No real model or personal data is used by those tests.

For independent identity administration and native execution, see the
[authority service](authority.md). Its CLI and HTTP bindings call the same
authenticated execution application. That API accepts registered agent IDs, pins
the approved definition and returns safe receipts. The legacy filesystem API
described above remains separate and does not enforce Agent House admission.
