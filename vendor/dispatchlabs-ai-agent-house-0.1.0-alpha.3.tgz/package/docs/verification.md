# Verification record

September 13, 2026, source alpha. Tested on Linux with Node.js 26.8.1, npm 11.19.0, Codex 0.154.0, and `gpt-6-astra` / `low`. Agent Wiki backend: 0.4.8, source commit `901c462b9e272ded3832135feeb6197db990a82e`.

## Reproduce

```sh
npm ci
npm run check
AGENT_HOUSE_WIKI_SOURCE=/path/to/agent-wiki npm test
AGENT_HOUSE_WIKI_SOURCE=/path/to/agent-wiki npm run smoke:wiki
```

The backend checkout needs its dependencies installed. The final command additionally requires native Codex authentication and consumes model usage. All wiki content, principals, grants, signing keys, and databases are generated in a temporary directory and removed afterward. It never uses a live wiki. Model/session logs remain private in the launcher and Codex state directories.

## Observed results

- Strict definition validation, duplicate-key rejection, stable hashing, and literal developer-instruction argument handling passed.
- An `npm pack` archive installed into a fresh temporary prefix; its installed `agent-house` executable validated the packaged example successfully. Formatting and all 11 tests passed with the optional real backend enabled.
- The account-free tests exercise a real stdio MCP subprocess through the private capability bridge. They check successful execution, missing executables, native failure, timeout, interruption, private file modes, and unconfirmed cleanup.
- Real-backend tests exercise enrolled machine authentication, reader-only tool exposure, distinct run IDs, principal mismatch, revoked keys, and server-side closure after success/failure/timeout.
- Two real native Codex sessions used one synthetic principal and different server run IDs. The first read `guide`, created `smoke-proof`, and read it back. The stored Git receipt carried the same agent/run as the launcher record. The second independently read the saved article. Both server runs were closed; the database had zero active runs afterward.
- A first smoke attempt exposed Codex's default interactive approval for write tools. The adapter now explicitly preapproves this connector's server-authorized tools. A completed native turn is not sufficient evidence of a completed task; the smoke test also checks the saved article and authoritative receipt.

## Follow-up qualification

The same definition hash, synthetic principal and credential binding passed real
read calls and instruction-marker verification in Codex 0.154.0, Claude Code
2.1.270 (`sonnet`, resolved by the native harness), and Pi 0.85.1
(`openai-codex/gpt-6-astra`). Each received a different server run ID and native
session ID; all runs closed. Pi's expired existing account was reauthenticated
through its normal browser login before qualification.

Application-independent identity tests cover grant denial/revocation, separate
configuration rights, immutable definitions and suspension. All 132 existing wiki
tests pass with the extracted identity module. Job tests cover duplicate input,
conflicting input, overlap and ambiguous-launch refusal. The deployed audit and
daily schedule are private Palm configuration, not portable package defaults.

macOS, resume, distributed scheduling, a standalone identity service and a public
package release remain unqualified. A first public release still needs
clean-environment qualification on claimed platforms and independent
security/open-source review.

## Independent native execution

Synthetic checks cover authenticated admission, immutable definition pinning,
request/occurrence deduplication, overlap denial, HTTP path/actor injection
rejection, credential scope, revocation during a native subprocess, resource run
closure and removal of the caller bearer token from the native environment.
The existing synthetic wiki tests still cover its own resource authorization.
A real read-only Codex/Astra/low execution also succeeded after independent
authority enrollment, with distinct authority/native/resource run links and
confirmed resource closure. No live content was used by the automated tests.
