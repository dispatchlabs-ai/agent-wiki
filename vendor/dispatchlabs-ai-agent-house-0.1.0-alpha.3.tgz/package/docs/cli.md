# CLI guide

The Agent House CLI loads a definition, opens one authorized wiki run, launches the selected native harness, and records the outcome. Its run commands do not enroll identities, create grants, or impersonate a human caller. Embedding applications can use the separate [identity module](identity.md) for control policy.

## Install and validate

Use Node.js 24.19 or newer and an installed, authenticated Codex CLI. The tested native version is 0.154.0 on Linux. Windows is unsupported; process cleanup uses POSIX process groups. macOS needs qualification.

```sh
npm ci
node bin/agent-house.mjs validate examples/wiki-editor.yaml --json
```

The example is synthetic and validates without connecting. `validate` checks the contract, rejects unknown fields and duplicate YAML keys, and computes a SHA-256 hash over the normalized definition. It does not check credentials, server grants, model availability, or whether a model accepts the selected thinking level. Codex performs the latter checks at execution; no fallback model is selected.

The required fields are `version: 2`, `name`, `principal`, `instructions`, `default_harness`, `harnesses` (a map with `model` and `thinking` for each configured harness), and `connections.wiki.credential_file`. Codex, Claude, and Pi are implemented. Pi additionally requires `harnesses.pi.provider`. Thinking accepts `minimal`, `low`, `medium`, `high`, `xhigh`, and `max`; Claude excludes `minimal`. The named model must support the value. The same labels do not imply equivalent reasoning across harnesses.

Harness configurations allow `--harness claude` or `--harness pi` to select an explicit model configuration while retaining the same principal, instructions and credential binding:

```yaml
default_harness: codex
harnesses:
  codex:
    model: gpt-6-astra
    thinking: low
  claude:
    model: sonnet
    thinking: low
  pi:
    provider: openai-codex
    model: gpt-6-astra
    thinking: low
```

There is no implicit cross-provider model substitution. The default must name a configured harness. Missing harness configurations are rejected. Claude appends instructions to its native system prompt, uses only the configured MCP server, disables built-in tools and preapproves this connector's tools. Pi appends instructions, disables discovered extensions/context/skills and built-in tools, and registers the bridge tools through an explicit extension. Each harness uses its existing authenticated account. The tested versions are Claude Code 2.1.270 and Pi 0.85.1 on Linux. Native session IDs and events are retained; resume is not implemented.

## Connect an enrolled principal

Copy `examples/wiki-editor.yaml` into a private configuration directory. Set `principal` to an existing enrolled agent ID. Set `credential_file` to its existing Agent Wiki connection JSON, relative to the definition file or absolute:

```json
{
  "version": 1,
  "endpoint": "https://wiki.example.org/mcp",
  "agent": "ENROLLED_AGENT_ID",
  "key": "ENROLLED_KEY_ID",
  "privateKeyFile": "/absolute/private/path/agent.pem",
  "scope": "wiki:read wiki:trace"
}
```

The private key must be an owned regular file with no group/other permissions; use mode 0600. Environment-variable keys are not supported by this CLI. Never place private keys in the definition or commit connection files. The agent ID must match the definition. Request `wiki:write` only when the enrolled principal has the appropriate grant and the task requires editing. The server enforces the grants; requested scopes cannot create permission.

The enrollment must already exist in the wiki's authorized operator workflow. The server binds the machine credential to its recorded initiator, authority mode, approved definition, and scope. Possession of that enrolled workload credential authorizes this initial launch path. The CLI does **not** authenticate the current human or implement a new human-to-agent invocation grant service. Moving enrollment and those checks into Agent House is future work.

## Run

```sh
node bin/agent-house.mjs run /path/to/wiki-editor.yaml \
  "Read guide using wiki.read and summarize its body" \
  --cwd /path/to/workspace --timeout 300 --json
```

Instructions are passed as Codex `developer_instructions`, retaining native harness guidance. The task is passed through standard input, without a shell. The launcher ignores user config/rules, disables apps, hooks, and multi-agent features, and installs its required wiki MCP bridge. Native project instructions and managed configuration may still apply; this is not a hermetic hosted agent. The filesystem sandbox is read-only. Wiki MCP tools execute outside that filesystem sandbox under the server's resource grants.

The connector explicitly preapproves the tools the wiki exposes, so unattended writes can proceed when the existing grant permits them. Running an edit task can modify wiki content. There is no per-tool interactive confirmation or automatic privilege escalation. These settings follow the native [Codex MCP configuration](https://learn.chatgpt.com/docs/extend/mcp) and [configuration reference](https://learn.chatgpt.com/docs/config-file/config-reference).

The signing credential remains in the launcher; the stdio MCP subprocess receives a temporary local bridge capability. Neither signing keys nor OAuth bearer tokens are passed as tool results. This is process plumbing, **not isolation from another process running as the same OS user**. Local tools may be able to read that user's files. Enforcing an approved prompt against an untrusted caller requires a separately isolated execution service.

## Results and exit codes

`--json` prints one final JSON run record on stdout; diagnostics go to stderr. Syntax/definition errors print a JSON error on stderr and exit 2. Human-readable output is the default.

| Exit | Meaning                                                  |
| ---- | -------------------------------------------------------- |
| 0    | Native turn completed and wiki run closure was confirmed |
| 1    | Runtime failure or unconfirmed wiki cleanup              |
| 2    | Invalid arguments, definition, or local setup            |
| 124  | Execution timed out                                      |
| 130  | Execution was interrupted                                |

`status: succeeded` means the native turn finished, not that the requested business outcome was proven. Inspect `result`, `tool_failures`, and application receipts. A model can finish by explaining a denied or unsuccessful operation. Automated jobs need their own acceptance criteria.

Each invocation records a fresh local UUID and server wiki run ID. `definition.sha256` identifies the local definition contents; `wiki.definition` is the server-approved definition ID. They are deliberately distinct. `wiki` also records the authoritative agent, initiator, mode, subject, and scope. `native_thread_id` links the native session. The CLI does not resume sessions yet.

Records are stored under `$XDG_STATE_HOME/agent-house/runs` or `~/.local/state/agent-house/runs`; `--state-dir` overrides this root. Run directories use mode 0700 and files mode 0600. `run.json` is updated atomically. `events.jsonl` and `stderr.log` preserve native output and may contain private tasks, resource data, and model responses. Codex also retains its own native session data. No automatic log retention policy is implemented. The temporary `bridge.json` is removed on ordinary completion, failure, timeout, or interruption.

The default timeout is 300 seconds, configurable up to 86400. Timeout and SIGINT/SIGTERM stop the native process group, with a three-second kill grace, and then close the wiki run. Connection/tool operations and cleanup have their own finite timeouts, so shutdown can exceed the requested task deadline. Hard termination or host failure can prevent cleanup; the server's run expiry/revocation remains the backstop. An unconfirmed closure is reported, not silently treated as success.

## Unattended use

A timer or service can execute the same `run` command with absolute paths, a prepared working directory, a suitable PATH, existing Codex authentication, and an enrolled credential. It does not require a terminal or user clicks. The timer account must have access to its own authorized credentials.

The CLI does not install cron entries or services. `run` always starts a new run. For scheduled work, use `job` with `--job-id NAME --occurrence OCCURRENCE` and the same definition/task/options as `run`. A private SQLite ledger admits an occurrence once and refuses overlapping occurrences of the same job. Replaying a completed occurrence returns its stored result with `replayed: true`. Changed input under the same occurrence is rejected.

This is at-most-once admission, not guaranteed exactly-once completion. An interrupted or ambiguous occurrence remains blocked for operator investigation; it is never retried automatically. A failed recorded result is also retained. Inspect native/application receipts before deliberately creating a new occurrence. There are no automatic stale-lock reclamation, distributed leases, or worker-pool controller yet. Separate admitted invocations share an agent principal but never a wiki run credential.

## Implementation provenance

`src/vendor/wiki-client.mjs` derives from Agent Wiki commit `901c462b9e272ded3832135feeb6197db990a82e` (version 0.4.8), under its retained MIT license. Changes expose cleanup status and preserve it through connection failure. The connector uses the wiki's client-credentials OAuth/MCP interface and `/api/agent/run`; it does not import the wiki application or database at runtime. Other applications need their own resource adapters and authorization contracts.

## Migrating the initial source-alpha definition

Replace `runtime.harness` with `default_harness`. Move the remaining `runtime`
settings into `harnesses.<default_harness>`, then move each entry from `profiles`
into `harnesses`. Remove `runtime` and `profiles`; mixed or old layouts are rejected.
Set `version: 2`; version 1 definitions are rejected with migration guidance. This changes
the local definition hash, not the principal or server-approved instructions.
Existing run receipts are retained. Do not reuse an admitted job occurrence with
the changed definition; the next scheduled occurrence uses the new definition.

`validate --harness pi --json` also checks that selection and reports its resolved
`runtime`. Run receipts still use `runtime` for the single configuration selected
for that execution; `harnesses` describes the available choices in the definition.
