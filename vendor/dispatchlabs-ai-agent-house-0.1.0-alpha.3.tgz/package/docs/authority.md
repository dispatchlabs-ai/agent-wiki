# Independent authority and administration API

Agent House can administer agents without Agent Wiki, a native harness, or a
model account. `Authority` owns a separate SQLite database, authenticated human
principals, hashed bearer credentials, immutable agent definitions, grants,
audit events and retry receipts. CLI and HTTP call its same `execute` method;
authentication and permissions are checked there even for direct callers.

This is a source-alpha control plane and native execution backend. `run.start`
admits a distinct durable execution with its authenticated initiator, credential
ID and immutable definition version. CLI and HTTP use the same execution service.
`agent.authorize` remains a permission check only. The legacy local `run`/`job`
commands remain available for existing deployments and do not use this authority;
use `call run.start` for independently authorized execution.

## Local setup

Use an explicit new database path in a private directory. Bootstrap is local-only,
requires an empty authority, and returns one administrator credential once:

```sh
umask 077
node bin/agent-house.mjs authority-init --database /private/agent-house/authority.sqlite3 \
  --name "Operator" --json > /private/agent-house/bootstrap.json
```

Keep the returned token in a secret store. It expires after 30 days. Set
`AGENT_HOUSE_TOKEN` through your secret manager when making authenticated calls;
never put tokens in command-line arguments or commit bootstrap output. An
administrator can issue a replacement credential before expiry and revoke the
old credential. There is no public bootstrap, password login, OIDC integration,
or lost-administrator recovery command yet. This version provisions humans;
service-principal provisioning is not implemented. For unattended work, issue a
human-delegated credential with `credential.issue` input `agent`: that credential
can only invoke/read runs for the specified agent, or check its invoke permission.
It cannot administer identities, change definitions or grant access, even when
its human principal is an administrator. It expires within 30 days and supports authenticated local renewal; it is not a service identity or a login session.

Each `call` reads a JSON input file. Local calls do not require a daemon:

```sh
node bin/agent-house.mjs call agent.create create.json \
  --database /private/agent-house/authority.sqlite3 --request-id create-auditor
```

Example `create.json`:

```json
{
  "name": "Auditor",
  "definition": {
    "version": 2,
    "instructions": "Verify claims against evidence and report corrections.",
    "default_harness": "codex",
    "harnesses": {
      "codex": { "model": "gpt-6-astra", "thinking": "low" }
    }
  }
}
```

The authority generates the principal and definition IDs. Hosted definitions
contain instructions and harness choices; caller-supplied principal IDs,
ownership, credential paths and resource grants are rejected. Name belongs to
the agent resource, not each definition revision. Local execution files still
contain their explicit principal and operator-owned connection binding.

## HTTP frontend

```sh
node bin/agent-house.mjs serve --database /private/agent-house/authority.sqlite3 --port 4320
node bin/agent-house.mjs call agent.list empty.json --url http://127.0.0.1:4320
```

`empty.json` contains `{}`. The server binds only to `127.0.0.1`. Use an explicit
HTTPS reverse proxy for remote access; the remote CLI accepts HTTPS or numeric
loopback HTTP and refuses redirects. No deployment is installed automatically.
Browser origins are rejected until a browser authentication policy is implemented.
The service uses bearer authentication, not cookies or shared OS-user identity.

Authenticated `GET /v1/operations` lists the catalog. For each operation below,
send `POST /v1/operations/<name>` with `Authorization: Bearer <token>` and
`Content-Type: application/json`. Mutations require an `Idempotency-Key` header
(`--request-id` in the CLI). Request bodies are limited to 64 KiB.

| Operation           | Input                                                   | Authorization                                |
| ------------------- | ------------------------------------------------------- | -------------------------------------------- |
| `principal.create`  | `name`                                                  | Administrator                                |
| `credential.issue`  | `principal`, `ttlSeconds` (1–2592000), optional `agent` | Administrator                                |
| `credential.revoke` | `credential` ID                                         | Administrator                                |
| `agent.create`      | `name`, `definition`                                    | Authenticated human becomes owner            |
| `agent.list`        | `{}`                                                    | Only owned or explicitly shared agents       |
| `agent.get`         | `agent` ID                                              | Any current agent control grant or ownership |
| `agent.configure`   | `agent`, `expectedDefinition`, `definition`             | Configure                                    |
| `agent.permission`  | `agent`, `principal`, `permission`, `enabled`           | Manage access                                |
| `agent.suspend`     | `agent`                                                 | Manage access                                |
| `agent.authorize`   | `agent`                                                 | Invoke                                       |

Ownership grants control of the agent. Explicit grants are `invoke`, `configure`,
and `manage-access`. None grants access to wiki content, email or repositories.
Administrator status permits principal/credential administration, not implicit
control of another person's agents. Administrators can issue credentials for
registered humans and must therefore be trusted as identity administrators.

Every request rechecks credential validity and current permissions, including
receipt replay. Mutation receipts are scoped to the authenticated principal and
request ID. Exact retries return the original result; changed inputs return
`IDEMPOTENCY_CONFLICT`. Object key ordering does not change request identity.
A stale configuration returns `REVISION_CONFLICT`; the old definition remains
immutable. Revoked/suspended access is denied rather than replaying sensitive
results to a caller who has lost access.

Credential secrets are hashed in storage and excluded from receipts. Retrying
`credential.issue` returns `CREDENTIAL_ALREADY_ISSUED` with its credential ID,
never the secret. If that first response is lost, revoke the ID and issue another
credential using a new request ID. Tokens are displayed only at issuance.

HTTP errors use `{ "code": "...", "error": "..." }`. Authentication failures are
401; administrative permission failures 403; inaccessible agents 404; stale or
conflicting requests 409. Unexpected failures return a generic 500 without server
paths or database details. CLI calls return the same domain error code in JSON
and exit 2 on rejected operations. Output is JSON for authority commands.

## Native execution

Register an existing resource identity using a trusted local operator command:

```sh
node bin/agent-house.mjs authority-enroll /private/auditor/agent.yaml \
  --database /private/agent-house/authority.sqlite3 --owner HUMAN_ID \
  --cwd /private/auditor/work
```

Enrollment preserves the existing agent principal and owner IDs, creates an
Agent House definition version, and binds its resource credential and working
directory. An operator can pass `--principal EXISTING_HUMAN_ID` to the initial
`authority-init` when preserving a known identity. These are trusted local
operations; neither arbitrary principal creation nor resource paths are accepted
through the execution HTTP API. Repeated identical enrollment is unchanged;
conflicting ownership, definitions or bindings are rejected.

The thin `invoke` command avoids making a JSON file:

```sh
node bin/agent-house.mjs invoke AGENT_ID "Read the guide" \
  --database /private/agent-house/authority.sqlite3 \
  --credential-file /private/auditor/authority-credential.json \
  --request-id unique-request --json
```

The credential file is the private JSON issuance response. Alternatively inject
`AGENT_HOUSE_TOKEN` from a secret manager. For daily work add `--job-id daily`
and `--occurrence YYYY-MM-DD` and use a stable request ID for that date. The same
command accepts `--url` for the HTTP frontend. It calls `run.start` below.

Create `run.json` containing `{"agent":"AGENT_ID","task":"Read the guide"}`:

```sh
node bin/agent-house.mjs call run.start run.json \
  --database /private/agent-house/authority.sqlite3 --request-id unique-request --json
```

An optional `harness` selects an explicitly configured runtime. Optional `job`
and `occurrence` must be provided together. They prevent duplicate occurrences
and overlapping runs of that job. Use a stable request ID per occurrence; retries
return the existing execution without launching another native session. A run
left `running` after a process/host crash remains ambiguous and blocks the next
job occurrence; inspect native/resource evidence before operator recovery. Do
not delete the ledger to retry. Concurrent independent runs without a job are
allowed. This is at-most-once admission, not durable queue supervision.

`call run.get` takes `{"run":"RUN_ID"}`. Invokers can read their own runs; the
owner can inspect all runs of the agent. HTTP uses these same operations and
waits for `run.start` to finish (host default 660 seconds); disconnected clients
can retrieve the receipt with `run.get` or retry the same request ID. HTTP/CLI
responses contain IDs, status, result and cleanup, not host paths or credentials.
An in-progress replay returns `status: running`; a CLI exit of zero for that
receipt does not mean the run completed. The host is still required to stay up.

Permissions are rechecked before connecting, before native launch, on every tool
request and response, and every 250 ms during execution. Revocation or suspension
stops the native process and closes the resource run. Regranting invoke access
does not revive a revoked execution. Already-dispatched resource requests may
complete; cancellation cannot undo their effects. The current wiki connector
continues enforcing its own reader/writer scope. Each private native run record
links its Agent House execution/definition/initiator to its native thread and
wiki run. The caller bearer token is removed from the native process environment.

Existing wiki records remain the resource-side identity, grants and historical
run ledger. Enrollment does not copy or delete that database. With the same-host
resource adapter enabled for an agent, the wiki requires its per-execution proof;
the signing key and legacy CLI alone can no longer open a resource run. This local alpha does not isolate
processes running under the same OS account; it is not a multi-tenant sandbox.

## Verification and remaining work

Synthetic tests use an independent temporary authority database: bootstrap,
create, grant, permission check, configure, stale update, revoke, credential
expiry, CLI/direct/HTTP parity, replay, spoofed actors and secret-free receipts.
The HTTP CLI test uses a real loopback server. No Agent Wiki or model is involved.

Execution tests additionally cover admission and definition pinning, job overlap,
retry conflicts, HTTP resource-path rejection, live native-process cancellation,
credential revocation, invocation-only delegation, and suppression of results
after revocation. Pending: first-class service principals, OIDC/SSO, administrator
recovery, general schema migrations, MCP bindings, browser authentication/UI,
cross-host federation, and persistent hosted job supervision. SQLite adds the
invocation-scope column automatically when opening the previous alpha database;
back up existing state before upgrading.

## Same-host resource authorization

The `./resource` module provides `authorizeResource(database, request)`. The
resource service opens the configured Agent House SQLite database read-only for
each decision. This is a same-host integration, not an OIDC federation protocol or
an HTTP introspection service. A resource service must be trusted with read access
to authority metadata; processes under one OS account are not isolated.

`run.start` creates a random resource capability scoped to the registered wiki
endpoint and execution deadline, stores only its hash, and passes it to the wiki
adapter in the signed client assertion. It never appears in the model's tools,
environment or run receipt. Wiki deployment opts in named agents using
`WIKI_AGENT_HOUSE_DATABASE` and comma-separated `WIKI_AGENT_HOUSE_AGENTS`.

For those agents, Agent Wiki requires the capability at token issuance, binds one
wiki run to that execution, and checks current execution status, principal,
credential, invoke permission and expiry before resource access. Missing state,
wrong audience, revoked credentials, suspended principals and finished executions
fail closed. Existing wiki space scopes still limit what the agent can read or
write. Renewal retains the same execution and wiki run; a second independent
session using the same execution proof is rejected. Closure remains permitted
after Agent House revocation, without permitting content access.

## Automatic credential renewal

```sh
node bin/agent-house.mjs rotate-credential --database /private/authority.sqlite3 \
  --credential-file /private/invoker.json --json
```

This local operation authenticates the current credential and renews it only
within seven days of expiry. It preserves the credential ID, principal and scope;
revocation of that ID invalidates every generation. New credentials last 30 days.
The previous secret remains usable for at most one hour (never beyond its old
expiry), allowing already-running work to finish. Expired/revoked credentials
cannot renew themselves. Output includes IDs, expiry and changed status only.

The mode-0600 pending file is synchronized before SQLite commit and promoted with
an atomic rename afterwards. A committed pending credential can recover on retry.
A per-file lock rejects concurrent maintenance; after a killed process, inspect
and remove the stale lock before retrying. Never delete a pending credential to
force renewal. Back up the authority database as well as credential files.

`scripts/maintain-credentials.mjs CONFIG.json` optionally integrates Personal
Vault for deployments that use `pv`. Config contains `database` and `credentials`
entries with the stable `id`, private `file`, and Vault `note` ID. It restores
missing files, renews due credentials and verifies changed secrets in Vault.
A failed backup retains the local current credential for retry and returns a
secret-free failure. Run it daily through the host scheduler; it requires Vault
to be unlocked. This renews Agent House bearer credentials, not application-owned
OAuth/signing keys or model-provider logins.
