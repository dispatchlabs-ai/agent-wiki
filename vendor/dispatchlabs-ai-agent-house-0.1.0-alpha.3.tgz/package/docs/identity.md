# Embedded identity policy

`@dispatchlabs-ai/agent-house/identity` exports `AgentIdentityStore`. It owns agent
creation/enrollment, immutable instruction/tool definitions, ownership transfer,
invoke/configure/manage-access grants, and suspension. It is extracted from
Agent Wiki under the retained MIT license.

The host supplies a SQLite connection, transactions, authenticated human
principals, and an audit table. `create`, `configure`, `permission`, `transfer`,
and `suspend` enforce the caller's applicable control permissions. Ownership
confers control of an agent, not permission to access application resources.
Revoked invocation grants are checked on every host-authorized use.

`enrollDefinition` is an operator-only primitive called inside the host's existing
transaction after authenticating the operator. It preserves stable IDs, rejects
conflicting registrations, and does not issue credentials or resource grants.
It is not a public unauthenticated registration endpoint. Caller-supplied IDs
are not proof of authentication.

The wiki subclasses the module and keeps resource scopes, delegations, signing
keys, token exchange, remote OAuth clients, and run lifecycle in its adapter.
Its `onRevokeInvoke` and `onSuspend` hooks invalidate remote grants and runs in
the same transaction. Existing database tables and IDs are retained, so adopting
the module requires no identity-copy migration or duplicate authority store.

The module has no wiki dependency. Tests create a Mail Researcher and repository
reviewer without a wiki, verify denied invocation/configuration, revoke grants,
and retain definition history. Those are policy tests, not mail/repository tool
integrations.

The embedded wiki integration moves implementation ownership without copying its
existing database or changing its authentication. Separately, the
[independent authority](authority.md) now hosts new Agent House principals and
administration through shared CLI/HTTP operations. Existing wiki identities have
not been migrated. Service-principal login, shared resource credentials and
standalone execution authorization remain future work. An arbitrary `--owner`
value is never authenticated human invocation.
