# Architecture

Agent House is an application-independent home for agent definitions and identities. It generalizes a model first developed for a wiki: an agent is both a principal that receives resource grants and a resource that other principals may be permitted to invoke or configure.

This document records the target architecture. The [CLI guide](cli.md) describes the implemented version 2 definitions, three native adapters, wiki credential binding and local job admission. The [identity module](identity.md) supplies shared control policy; the [independent authority](authority.md) now supplies its own database and CLI/HTTP administration and native execution admission. Resource federation remains future work.

## Shared backend and thin interfaces

Agent House is a headless application for creating agents and talking to them.
The CLI, HTTP API, MCP, and future web/desktop/mobile clients use one set of
application services. This follows the Books direction: the CLI is a frontend,
not the owner of application workflows. Local CLI calls may invoke services
in-process; they do not require HTTP, microservices, or a running daemon.

| Layer                          | Responsibility                                                                                                                              |
| ------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------- |
| CLI                            | Parse arguments and definition files, present results, map errors to exit codes                                                             |
| HTTP and MCP adapters          | Authenticate connections, validate wire formats, translate requests and responses                                                           |
| Application services           | Authorize operations; orchestrate agent creation, configuration, grants, conversations, runs and jobs; own retry and transaction boundaries |
| Domain policy                  | Enforce principal identity, immutable definitions, grants, revocation and valid lifecycle transitions                                       |
| Storage and execution adapters | Persist state and evidence, connect resource services, and drive native harnesses or optional compute                                       |

Authentication supplies a trusted caller context; an arbitrary actor string or
local OS username does not grant authority. Shared services enforce permissions
even when invoked directly without HTTP. Each resource application still enforces
its own permissions. Frontends neither access application tables directly nor
execute CLI subprocesses as their backend API.

Maintain an operation catalog with request/result types, permissions, error codes,
retry semantics and interface coverage. Every supported application operation,
including administration, should have CLI, HTTP and MCP bindings. An interface
must not be the reason an authorized operation is unavailable. Record incomplete
coverage explicitly until parity exists; do not advertise it as implemented.
Remote clients use resource IDs and supported upload/export operations rather
than selecting server filesystem paths or receiving private credential files.

The same backend supports local and hosted operation. Hosted runs and jobs must
outlive client disconnects and expose durable status, results, cancellation and
resumable events. This does not require local foreground CLI runs to become a
daemon immediately. Use shared errors, definition revision checks and idempotency
receipts across interfaces, and test equivalent operations and denied direct
service calls against synthetic state.

Agent Bridge's web UI and gateways are components to bring into Agent House,
not a separate required product. Keep native execution and optional Dispatch
compute behind adapters. The current CLI already calls reusable functions, but
the independent authority now adds authenticated CLI/HTTP administration and
native execution. Resume, durable supervision, service principals, MCP and the
merged UI remain unfinished.

Decision evidence: [Books frontend direction, September 12](https://wiki.chrisreynolds.me/conversations/chat-5ca8f8c6597921484b5e2c04/#e-ca4bc4bdca1fc21cde75),
[local calls need no HTTP](https://wiki.chrisreynolds.me/conversations/chat-5ca8f8c6597921484b5e2c04/#e-665aa6279be0802b33ac), and
[Books shared-backend and interface-parity follow-up, September 13](https://wiki.chrisreynolds.me/conversations/chat-9ca01923f35320198b11a85b/#e-aef661b7a46385f85ed2).
These establish the design direction; Books' ongoing implementation is not proof
that either application has completed all interfaces.

## Core objects

| Object             | Responsibility                                                                                                        |
| ------------------ | --------------------------------------------------------------------------------------------------------------------- |
| Principal          | Stable identity for a human, agent, or invoking service                                                               |
| Agent definition   | Versioned name, instructions, tool requirements, and runtime defaults                                                 |
| Grant              | Permission to invoke, configure, or manage access to an agent; resource grants remain subject to the resource service |
| Credential binding | Reference to credentials available to an approved runtime; never a secret embedded in the definition                  |
| Job                | Task input, trigger, resource selection, execution budget, concurrency, and completion criteria                       |
| Run                | One execution with actor, initiator, definition version, native session reference, status, and results                |

An owner does not automatically confer its resource privileges on an agent. Copying a definition cannot create grants. Registration must distinguish updating an existing principal from deliberately creating another.

## Definition authoring

Keep the common form small: name, instructions, principal/owner, access settings, default harness, model, and thinking level. `default_harness` selects one entry in `harnesses`, which supplies model settings for Codex, Claude, and Pi without changing the principal.

Use instructions as the portable concept. Each adapter must document whether it appends to native instructions, uses a developer instruction layer, or supplies a system prompt. Preserve the harness's necessary operating guidance unless replacement is explicitly intended. Thinking levels must be checked against the selected model and harness; identical labels do not promise identical behavior.

Reject unsupported required settings before launch. Record the resolved configuration and immutable definition version. The initial CLI validates the version 2 format in `examples/wiki-editor.yaml`; it records a local content hash separately from the authoritative server definition ID. Codex, Claude and Pi configurations are supported.

## Authority and invocation

A run selects one explicit authority mode:

- Independent: use grants assigned to the agent.
- Delegated: use an authorized subset of a human's current rights.

Never silently combine those rights or retry a denied operation under broader authority. Scheduled work can use either mode.

For a manual launch, record the human initiator. For a scheduled launch, authenticate the invoking service, check its invocation grant, and record the job and its authorizing principal. A schedule is configuration, not an identity or a login session.

Issue bounded, audience-specific run credentials. Model-provider authentication is separate from authorization to use wiki, mail, or Git resources. External APIs must explicitly trust the issuer or be accessed through a compatible credential broker; a generic agent token does not automatically work everywhere.

Keep invocation, definition editing, and management of access separate. Check current grants and revocation at sensitive operations. Define whether changed definitions affect existing runs; preserve explicit version binding rather than silently rewriting running agents.

## Execution boundaries

Agent House resolves and authorizes an execution request. A backend starts the native harness, supplies its configuration and credentials, reports progress, and preserves the native session identity on resume. Optional compute systems allocate machines or containers.

Agent Bridge supplies existing gateway and UI components for Agent House; Dispatch is an optional compute backend. These integrations must use documented interfaces and remain optional. Agent House must not require a particular private infrastructure or deployment.

MCP connects tools and resources. A2A can expose task/result interfaces to external agents. Neither replaces the complete definition and authorization contract. Open Agent Specification and existing cross-harness adapters should be assessed before implementing redundant translation code.

Giving a caller an agent's tools in an unrestricted local harness does not prove that caller uses the approved instructions. If a product promises a hosted specialist, execute its approved definition in a trusted backend and expose the task/result interface. Resource services enforce consequential permissions outside prompt text.

## Concurrent workers

One definition and principal can have many runs. Give each run its own context, native session, credential scope, work claims, and result attribution. Sharing a saved OAuth authorization must not collapse all worker executions into one run.

Jobs can be triggered manually, by time, or by events. Durable occurrence IDs, leases, bounded retries, cancellation and result receipts belong in the job lifecycle. A timer alone does not provide these semantics. Reuse existing compute ownership and lease mechanisms rather than introducing competing controllers.

Exploration may choose its own targets and follow promising leads. Bound execution and record coverage, evidence, accepted findings, duplicate effort, and cost. Use revision checks for wiki edits and independent workspaces with coordinated integration for repository changes. Retried work must not duplicate effects.

## Initial application contracts

- Mail research: read authorized messages and context, save a cited brief keyed to message/thread revision. Sending mail requires a separate capability.
- Wiki editing: prove an error, re-read the current revision, make a minimal correction, and retain its evidence.
- Repository review: produce a reproducible finding or supported code analysis, then a tested change where authorized.
- Trace research: produce evidence-backed suggestions for instruction and skill improvements; suggestions do not silently change the worker's own governing policy.

## Standards references

- [Open Agent Specification](https://github.com/oracle/agent-spec)
- [MCP authorization](https://modelcontextprotocol.io/specification/2025-11-25/basic/authorization)
- [MCP machine credentials](https://modelcontextprotocol.io/extensions/auth/oauth-client-credentials)
- [A2A](https://a2a-protocol.org/latest/specification/)
- [Agent Skills](https://agentskills.io/specification)

These are references, not claims that Agent House currently conforms to them.
