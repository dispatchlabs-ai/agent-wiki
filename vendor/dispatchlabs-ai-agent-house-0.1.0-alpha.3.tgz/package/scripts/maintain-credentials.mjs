#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { Authority } from "../src/authority.mjs";
import { rotateCredentialFile } from "../src/rotation.mjs";

// Operator configuration only. Never prints credentials or subprocess diagnostics.
let authority;
try {
  const config = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
  authority = new Authority(config.database);
  const results = [];
  for (const item of config.credentials) {
    const stored = JSON.parse(
      execFileSync("pv", ["--raw", "note", "get", item.note], {
        encoding: "utf8",
        stdio: ["ignore", "pipe", "pipe"],
        timeout: 30000,
      }),
    );
    if (stored.id !== item.id) throw Error("Vault credential identity differs");
    if (!fs.existsSync(item.file)) {
      authority.authenticate(stored.token);
      fs.mkdirSync(path.dirname(item.file), { recursive: true, mode: 0o700 });
      fs.writeFileSync(item.file, JSON.stringify(stored), {
        mode: 0o600,
        flag: "wx",
      });
    }
    const local = JSON.parse(fs.readFileSync(item.file, "utf8"));
    if (local.id !== item.id) throw Error("Local credential identity differs");
    const result = rotateCredentialFile(authority, item.file);
    const current = JSON.parse(fs.readFileSync(item.file, "utf8"));
    const synchronized = stored.token !== current.token;
    if (synchronized) {
      execFileSync("pv", ["note", "set", item.note, "--stdin"], {
        input: JSON.stringify(current),
        stdio: ["pipe", "pipe", "pipe"],
        timeout: 30000,
      });
      const verified = JSON.parse(
        execFileSync("pv", ["--raw", "note", "get", item.note], {
          encoding: "utf8",
          stdio: ["ignore", "pipe", "pipe"],
          timeout: 30000,
        }),
      );
      if (verified.token !== current.token)
        throw Error("Vault readback differs");
    }
    results.push({ ...result, vaultSynchronized: synchronized });
  }
  console.log(JSON.stringify({ ok: true, credentials: results }));
} catch {
  console.error(
    JSON.stringify({
      ok: false,
      error:
        "Credential maintenance failed. Check Vault access, expiry, revocation and any interrupted rotation lock; current credential files were retained.",
    }),
  );
  process.exitCode = 1;
} finally {
  authority?.close();
}
