import http from "node:http";
import { authorityOperations } from "./authority.mjs";

export function createAuthorityServer(authority) {
  const server = http.createServer(async (request, response) => {
    const send = (status, body) => {
      response.writeHead(status, {
        "content-type": "application/json; charset=utf-8",
        "cache-control": "no-store",
        "x-content-type-options": "nosniff",
      });
      response.end(JSON.stringify(body));
    };
    try {
      if (request.headers.origin)
        return send(403, {
          code: "ORIGIN_REJECTED",
          error: "Browser origins are not enabled",
        });
      const authorization = request.headers.authorization || "";
      if (!authorization.startsWith("Bearer "))
        return send(401, {
          code: "UNAUTHENTICATED",
          error: "Bearer credential required",
        });
      const token = authorization.slice(7);
      authority.authenticate(token);
      if (request.method === "GET" && request.url === "/v1/operations")
        return send(200, {
          operations: authority.operations || authorityOperations,
        });
      const match = /^\/v1\/operations\/([a-z.]+)$/.exec(request.url || "");
      if (request.method !== "POST" || !match)
        return send(404, { code: "NOT_FOUND", error: "Not found" });
      if (
        request.headers["content-type"]?.split(";")[0].trim() !==
        "application/json"
      )
        return send(415, {
          code: "UNSUPPORTED_MEDIA_TYPE",
          error: "Use application/json",
        });
      const chunks = [];
      let bytes = 0;
      for await (const chunk of request) {
        bytes += chunk.length;
        if (bytes > 65536) {
          send(413, {
            code: "BODY_TOO_LARGE",
            error: "Request exceeds 65536 bytes",
          });
          request.resume();
          return;
        }
        chunks.push(chunk);
      }
      let input;
      try {
        input = JSON.parse(Buffer.concat(chunks).toString("utf8"));
      } catch {
        return send(400, { code: "INVALID_JSON", error: "Invalid JSON" });
      }
      send(
        200,
        await authority.execute(
          token,
          match[1],
          input,
          request.headers["idempotency-key"],
        ),
      );
    } catch (error) {
      const expected =
        Number.isInteger(error.status) &&
        error.status >= 400 &&
        error.status < 500;
      send(expected ? error.status : 500, {
        code: expected ? error.code : "INTERNAL_ERROR",
        error: expected ? error.message : "Operation failed",
      });
    }
  });
  server.requestTimeout = 15000;
  server.headersTimeout = 10000;
  server.maxHeadersCount = 32;
  return server;
}
