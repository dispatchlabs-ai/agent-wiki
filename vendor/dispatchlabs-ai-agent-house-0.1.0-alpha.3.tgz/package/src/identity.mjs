// Extracted from Agent Wiki (MIT, Chris Reynolds). Application resource policy stays in adapters.
import { randomUUID } from "node:crypto";
const controls = new Set(["invoke", "configure", "manage-access"]);
export class IdentityError extends Error {
  constructor(code, message, status = 400) {
    super(message);
    this.code = code;
    this.status = status;
  }
}
export class AgentIdentityStore {
  constructor(
    control,
    { now = () => Date.now(), ErrorType = IdentityError } = {},
  ) {
    this.control = control;
    this.db = control.db;
    this.now = now;
    this.ErrorType = ErrorType;
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS agents(id TEXT PRIMARY KEY REFERENCES principals(id), owner TEXT NOT NULL REFERENCES principals(id), definition TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS agent_definitions(id TEXT PRIMARY KEY, agent TEXT NOT NULL REFERENCES agents(id), config TEXT NOT NULL, created INTEGER NOT NULL);
      CREATE TABLE IF NOT EXISTS agent_permissions(agent TEXT NOT NULL REFERENCES agents(id), principal TEXT NOT NULL REFERENCES principals(id), permission TEXT NOT NULL CHECK(permission IN ('invoke','configure','manage-access')), PRIMARY KEY(agent,principal,permission));
    `);
  }
  fail() {
    throw new this.ErrorType("NOT_FOUND", "Not found", 404);
  }
  text(value) {
    if (typeof value !== "string" || !value.trim() || value.length > 200)
      throw new this.ErrorType("INVALID_AGENT", "Invalid agent input", 400);
    return value;
  }
  onRevokeInvoke(_agent, _principal) {}
  onSuspend(_agent) {}
  // Trusted enrollment operation; the calling application authenticates the operator.
  enrollDefinition(id, owner, name, definition) {
    this.human(owner);
    name = this.text(name);
    const config = this.definition(definition);
    const a = this.db
      .prepare(
        "SELECT a.*,p.name FROM agents a JOIN principals p ON p.id=a.id WHERE a.id=?",
      )
      .get(id);
    if (a) {
      if (
        a.owner !== owner ||
        a.name !== name ||
        this.db
          .prepare("SELECT config FROM agent_definitions WHERE id=?")
          .get(a.definition).config !== config
      )
        throw new this.ErrorType(
          "REGISTRATION_CONFLICT",
          "Existing agent definition or owner differs",
          409,
        );
      this.get(id);
      return { agent: id, changed: false };
    }
    const version = randomUUID();
    this.db
      .prepare("INSERT INTO principals(id,kind,name) VALUES (?,'agent',?)")
      .run(id, name);
    this.db
      .prepare("INSERT INTO agents VALUES (?,?,?)")
      .run(id, owner, version);
    this.db
      .prepare("INSERT INTO agent_definitions VALUES (?,?,?,?)")
      .run(version, id, config, this.now());
    this.record("operator", "agent:create", id);
    return { agent: id, changed: true };
  }
  principal(id) {
    return (
      this.db
        .prepare("SELECT * FROM principals WHERE id=? AND active=1")
        .get(id) || this.fail()
    );
  }
  human(id) {
    const p = this.principal(id);
    if (p.kind !== "human") this.fail();
    return p;
  }
  record(actor, action, target) {
    this.db
      .prepare("INSERT INTO audit(actor,action,target) VALUES (?,?,?)")
      .run(actor, action, target);
  }
  get(id) {
    return (
      this.db
        .prepare(
          "SELECT a.*,p.name FROM agents a JOIN principals p ON p.id=a.id WHERE a.id=? AND p.active=1",
        )
        .get(id) || this.fail()
    );
  }
  allowed(actor, agent, permission) {
    this.principal(actor);
    const a = this.get(agent);
    return (
      a.owner === actor ||
      !!this.db
        .prepare(
          "SELECT 1 FROM agent_permissions WHERE agent=? AND principal=? AND permission=?",
        )
        .get(agent, actor, permission)
    );
  }
  require(actor, agent, permission) {
    if (!this.allowed(actor, agent, permission)) this.fail();
  }
  list(actor) {
    this.human(actor);
    return this.db
      .prepare(
        "SELECT a.*,p.name,p.active FROM agents a JOIN principals p ON p.id=a.id WHERE a.owner=? OR EXISTS (SELECT 1 FROM agent_permissions g WHERE g.agent=a.id AND g.principal=?) ORDER BY p.name",
      )
      .all(actor, actor);
  }
  definition(value) {
    if (
      !value ||
      typeof value !== "object" ||
      Array.isArray(value) ||
      typeof value.instructions !== "string" ||
      value.instructions.length > 20000 ||
      !Array.isArray(value.tools) ||
      value.tools.length > 100 ||
      value.tools.some((t) => typeof t !== "string" || t.length > 200) ||
      Object.keys(value).some((k) => !["instructions", "tools"].includes(k))
    )
      throw new this.ErrorType(
        "INVALID_DEFINITION",
        "Specify instructions and tool names only; credentials do not belong in definitions",
        400,
      );
    return JSON.stringify(value);
  }
  create(actor, { name, definition }) {
    this.human(actor);
    name = this.text(name);
    const config = this.definition(definition);
    return this.control.transaction(() => {
      const id = randomUUID(),
        version = randomUUID();
      this.db
        .prepare("INSERT INTO principals(id,kind,name) VALUES (?,'agent',?)")
        .run(id, name);
      this.db
        .prepare("INSERT INTO agents VALUES (?,?,?)")
        .run(id, actor, version);
      this.db
        .prepare("INSERT INTO agent_definitions VALUES (?,?,?,?)")
        .run(version, id, config, this.now());
      this.record(actor, "agent:create", id);
      return this.get(id);
    });
  }
  configure(actor, agent, definition) {
    const config = this.definition(definition);
    return this.control.transaction(() => {
      this.require(actor, agent, "configure");
      const id = randomUUID();
      this.db
        .prepare("INSERT INTO agent_definitions VALUES (?,?,?,?)")
        .run(id, agent, config, this.now());
      this.db
        .prepare("UPDATE agents SET definition=? WHERE id=?")
        .run(id, agent);
      this.record(actor, "agent:configure", agent);
      return { definition: id };
    });
  }
  permission(actor, agent, principal, permission, enabled) {
    if (!controls.has(permission) || typeof enabled !== "boolean")
      throw new this.ErrorType(
        "INVALID_PERMISSION",
        "Invalid agent permission",
        400,
      );
    return this.control.transaction(() => {
      this.require(actor, agent, "manage-access");
      this.human(principal);
      if (enabled)
        this.db
          .prepare("INSERT OR IGNORE INTO agent_permissions VALUES (?,?,?)")
          .run(agent, principal, permission);
      else
        this.db
          .prepare(
            "DELETE FROM agent_permissions WHERE agent=? AND principal=? AND permission=?",
          )
          .run(agent, principal, permission);
      if (!enabled && permission === "invoke")
        this.onRevokeInvoke(agent, principal);
      this.record(
        actor,
        "agent:permission:" + permission + ":" + enabled,
        agent + ":" + principal,
      );
    });
  }
  transfer(actor, agent, owner) {
    return this.control.transaction(() => {
      this.require(actor, agent, "manage-access");
      this.human(owner);
      this.db.prepare("UPDATE agents SET owner=? WHERE id=?").run(owner, agent);
      this.record(actor, "agent:owner", agent + ":" + owner);
    });
  }
  suspend(actor, agent) {
    return this.control.transaction(() => {
      this.require(actor, agent, "manage-access");
      this.db.prepare("UPDATE principals SET active=0 WHERE id=?").run(agent);
      this.onSuspend(agent);
      this.record(actor, "agent:suspend", agent);
    });
  }
}
