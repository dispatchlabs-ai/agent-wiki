export function authorizeResource(
  database: string,
  request: {
    agent: string;
    audience: string;
    proof?: string;
    execution?: string;
  },
  now?: number,
): { execution: string; agent: string; initiator: string; definition: string };
