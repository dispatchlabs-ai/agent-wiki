import fs from "node:fs";
import path from "node:path";
import { randomBytes, createHash } from "node:crypto";
import { IdentityError } from "./identity.mjs";
const digest = (token) => createHash("sha256").update(token).digest("hex");
const read = (file) => {
  const stat = fs.lstatSync(file);
  if (
    !stat.isFile() ||
    stat.mode & 0o077 ||
    (process.getuid && stat.uid !== process.getuid())
  )
    throw Error("Credential must be an owned mode-0600 regular file");
  return JSON.parse(fs.readFileSync(file, "utf8"));
};
// Local credential-file maintenance, not an unauthenticated HTTP renewal endpoint.
// A durable pending file bridges SQLite commit and atomic file replacement.
export function rotateCredentialFile(
  authority,
  filename,
  { renewBefore = 7 * 86400000, ttl = 30 * 86400000 } = {},
) {
  if (
    !Number.isSafeInteger(renewBefore) ||
    renewBefore < 0 ||
    !Number.isSafeInteger(ttl) ||
    ttl < 3600000 ||
    ttl > 30 * 86400000 ||
    renewBefore >= ttl
  )
    throw Error("Invalid renewal window");
  filename = path.resolve(filename);
  const pending = filename + ".pending";
  const lock = filename + ".lock";
  try {
    fs.mkdirSync(lock, { mode: 0o700 });
  } catch {
    throw Error(
      "Credential rotation is locked; inspect interrupted maintenance before removing its lock",
    );
  }
  const syncDirectory = () => {
    const fd = fs.openSync(path.dirname(filename), "r");
    try {
      fs.fsyncSync(fd);
    } finally {
      fs.closeSync(fd);
    }
  };
  try {
    const old = read(filename);
    let recovered = false;
    if (fs.existsSync(pending)) {
      const candidate = read(pending);
      const row = authority.db
        .prepare("SELECT * FROM credentials WHERE id=?")
        .get(old.id);
      if (candidate.id !== old.id || candidate.principal !== old.principal)
        throw Error("Pending credential identity differs");
      if (row?.digest === digest(candidate.token)) {
        authority.authenticate(candidate.token);
        fs.renameSync(pending, filename);
        syncDirectory();
        recovered = true;
      } else {
        authority.authenticate(old.token);
        fs.unlinkSync(pending);
      }
    }
    const current = read(filename);
    const principal = authority.authenticate(current.token);
    return authority.transaction(() => {
      const row = authority.db
        .prepare("SELECT * FROM credentials WHERE id=? AND digest=?")
        .get(current.id, digest(current.token));
      if (!row || row.principal !== principal)
        throw new IdentityError(
          "STALE_CREDENTIAL",
          "Only the current credential can renew",
          409,
        );
      if (row.invoke_agent)
        authority.agents.require(principal, row.invoke_agent, "invoke");
      if (row.expires - authority.now() > renewBefore)
        return { changed: recovered, id: row.id, expires: row.expires };
      const token = randomBytes(32).toString("base64url");
      const next = {
        id: row.id,
        principal,
        token: "ah_" + token,
        expires: authority.now() + ttl,
        ...(row.invoke_agent ? { invoke_agent: row.invoke_agent } : {}),
      };
      const fd = fs.openSync(pending, "wx", 0o600);
      try {
        fs.writeFileSync(fd, JSON.stringify(next));
        fs.fsyncSync(fd);
      } finally {
        fs.closeSync(fd);
      }
      syncDirectory();
      authority.db
        .prepare(
          "UPDATE credentials SET previous_digest=digest,previous_expires=?,digest=?,expires=? WHERE id=?",
        )
        .run(
          Math.min(row.expires, authority.now() + 3600000),
          digest(next.token),
          next.expires,
          row.id,
        );
      authority.agents.record(principal, "credential:rotate", row.id);
      return { changed: true, id: row.id, expires: next.expires };
    });
  } finally {
    // Only promote a committed pending credential. If commit failed, the old file remains usable.
    if (fs.existsSync(pending)) {
      const next = read(pending);
      const row = authority.db
        .prepare("SELECT digest FROM credentials WHERE id=?")
        .get(next.id);
      if (row?.digest === digest(next.token)) {
        fs.renameSync(pending, filename);
        syncDirectory();
      }
    }
    fs.rmdirSync(lock);
  }
}
