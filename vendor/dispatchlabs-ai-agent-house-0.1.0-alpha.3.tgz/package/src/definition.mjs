import fs from "node:fs";
import path from "node:path";
import { createHash } from "node:crypto";
import { parseDocument } from "yaml";

function object(value, keys, label) {
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw Error(`${label} must be an object`);
  for (const key of Object.keys(value))
    if (!keys.includes(key)) throw Error(`Unsupported ${label} field: ${key}`);
}
function string(value, label) {
  if (typeof value !== "string" || !value.trim())
    throw Error(`${label} must be a nonempty string`);
}
export function validateDefinition(d) {
  if (d?.version !== 2)
    throw Error(
      "Use definition version 2 with default_harness and harnesses; migrate runtime/profiles as described in docs/cli.md",
    );

  object(
    d,
    [
      "version",
      "name",
      "principal",
      "instructions",
      "default_harness",
      "connections",
      "harnesses",
    ],
    "definition",
  );
  for (const key of ["name", "principal", "instructions"]) string(d[key], key);
  validateHarnesses(d);
  object(d.connections, ["wiki"], "connections");
  object(d.connections.wiki, ["credential_file"], "connections.wiki");
  string(
    d.connections.wiki.credential_file,
    "connections.wiki.credential_file",
  );
  return d;
}
export function validateHarnesses(d) {
  if (!["codex", "claude", "pi"].includes(d.default_harness))
    throw Error("Unsupported default_harness");
  object(d.harnesses, ["codex", "claude", "pi"], "harnesses");
  for (const [harness, settings] of Object.entries(d.harnesses)) {
    object(settings, ["model", "thinking", "provider"], `harnesses.${harness}`);
    validateRuntime({ ...settings, harness });
  }
  resolveRuntime(d);
}
export function validateRuntime(runtime) {
  object(runtime, ["harness", "model", "thinking", "provider"], "runtime");
  const d = { runtime };
  if (!["codex", "claude", "pi"].includes(runtime.harness))
    throw Error("Unsupported harness");
  string(d.runtime.model, "runtime.model");
  if (
    !(
      runtime.harness === "claude"
        ? ["low", "medium", "high", "xhigh", "max"]
        : ["minimal", "low", "medium", "high", "xhigh", "max"]
    ).includes(d.runtime.thinking)
  )
    throw Error("Unsupported thinking level");
  if (runtime.harness === "pi") string(runtime.provider, "runtime.provider");
  else if (runtime.provider !== undefined)
    throw Error("provider is only supported by Pi");
  return runtime;
}
export function resolveRuntime(
  definition,
  harness = definition.default_harness,
) {
  if (!Object.hasOwn(definition.harnesses, harness))
    throw Error(`No harness configuration for ${harness}`);
  return validateRuntime({ ...definition.harnesses[harness], harness });
}
export function loadDefinition(filename) {
  const absolute = path.resolve(filename);
  const doc = parseDocument(fs.readFileSync(absolute, "utf8"), {
    uniqueKeys: true,
  });
  if (doc.errors.length) throw Error(`Invalid YAML: ${doc.errors[0].message}`);
  const definition = validateDefinition(doc.toJS({ maxAliasCount: 20 }));
  // Hash the normalized contract, independent of YAML whitespace/key order.
  const canonical = (value) =>
    value && typeof value === "object"
      ? Object.fromEntries(
          Object.keys(value)
            .sort()
            .map((key) => [key, canonical(value[key])]),
        )
      : value;
  const hash = createHash("sha256")
    .update(JSON.stringify(canonical(definition)))
    .digest("hex");
  return {
    definition,
    hash,
    filename: absolute,
    credentialFile: path.resolve(
      path.dirname(absolute),
      definition.connections.wiki.credential_file,
    ),
  };
}
