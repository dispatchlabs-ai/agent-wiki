import { loadDefinition, resolveRuntime } from "./definition.mjs";
import { runAgent } from "./run.mjs";
import { runJob } from "./jobs.mjs";

// Coverage is explicit: this is a local application boundary, not a hosted API.
export const operations = Object.freeze({
  "definition.validate": Object.freeze({
    effect: "read",
    authority: "none",
    cli: "validate",
    http: false,
    mcp: false,
  }),
  "run.start": Object.freeze({
    effect: "execute",
    authority: "enrolled-resource-credential",
    cli: "run",
    http: false,
    mcp: false,
  }),
  "job.execute": Object.freeze({
    effect: "execute",
    authority: "enrolled-resource-credential",
    cli: "job",
    http: false,
    mcp: false,
  }),
});

export class ApplicationError extends Error {
  constructor(code, message, options) {
    super(message, options);
    this.name = "ApplicationError";
    this.code = code;
  }
}

function invalid(message) {
  throw new ApplicationError("INVALID_REQUEST", message);
}

// Dependencies are supplied by the trusted host, never by an operation request.
// The filesystem repository and process executor are for local operation only.
export function createApplication({
  definitions = { load: loadDefinition },
  executeRun = runAgent,
  jobStateDir,
} = {}) {
  return Object.freeze({
    async execute(operation, request) {
      if (!Object.hasOwn(operations, operation))
        throw new ApplicationError(
          "UNKNOWN_OPERATION",
          `Unknown operation: ${operation}`,
        );
      if (!request || typeof request !== "object" || Array.isArray(request))
        invalid("Request must be an object");
      const validation = operation === "definition.validate";
      const keys = validation
        ? ["definition", "harness"]
        : [
            "definition",
            "harness",
            "task",
            "cwd",
            "stateDir",
            "timeout",
            ...(operation === "job.execute" ? ["jobId", "occurrence"] : []),
          ];
      for (const key of Object.keys(request))
        if (!keys.includes(key)) invalid(`Unsupported request field: ${key}`);
      if (typeof request.definition !== "string" || !request.definition.trim())
        invalid("A definition reference is required");
      if (
        request.harness !== undefined &&
        !["codex", "claude", "pi"].includes(request.harness)
      )
        invalid("Unsupported harness");
      if (!validation) {
        if (typeof request.task !== "string" || !request.task.trim())
          invalid("A nonempty task is required");
        for (const key of ["cwd", "stateDir"])
          if (
            request[key] !== undefined &&
            (typeof request[key] !== "string" || !request[key].trim())
          )
            invalid(`${key} must be a nonempty path`);
        if (
          request.timeout !== undefined &&
          (typeof request.timeout !== "number" ||
            !Number.isFinite(request.timeout) ||
            request.timeout <= 0 ||
            request.timeout > 86400)
        )
          invalid("timeout must be greater than 0 and at most 86400 seconds");
        if (operation === "job.execute")
          for (const key of ["jobId", "occurrence"])
            if (typeof request[key] !== "string" || !request[key].trim())
              invalid(`${key} is required`);
      }
      let loaded, runtime;
      try {
        loaded = await definitions.load(request.definition);
        runtime = resolveRuntime(loaded.definition, request.harness);
      } catch (cause) {
        throw new ApplicationError("INVALID_DEFINITION", cause.message, {
          cause,
        });
      }
      if (validation)
        return {
          valid: true,
          name: loaded.definition.name,
          principal: loaded.definition.principal,
          sha256: loaded.hash,
          default_harness: loaded.definition.default_harness,
          harnesses: loaded.definition.harnesses,
          runtime,
        };
      const options = {
        cwd: request.cwd,
        stateDir: request.stateDir,
        timeout: request.timeout ?? 300,
        harness: runtime.harness,
      };
      // runAgent retains the actual credential exchange, principal binding and
      // authoritative run admission. No caller-supplied actor grants authority.
      if (operation === "run.start")
        return executeRun(loaded, request.task, options);
      return runJob(loaded, request.task, {
        ...options,
        jobId: request.jobId,
        occurrence: request.occurrence,
        jobStateDir,
        execute: executeRun,
      });
    },
  });
}
