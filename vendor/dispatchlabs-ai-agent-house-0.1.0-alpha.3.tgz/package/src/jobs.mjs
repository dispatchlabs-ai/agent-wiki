import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { createHash } from "node:crypto";
import { DatabaseSync } from "node:sqlite";
import { runAgent } from "./run.mjs";

// At-most-once admission. A crashed/ambiguous occurrence is never automatically replayed.
export async function runJob(loaded, task, options = {}) {
  if (!options.jobId || !options.occurrence)
    throw Error("job requires --job-id and --occurrence");
  const directory = path.resolve(
    options.jobStateDir ||
      path.join(
        process.env.XDG_STATE_HOME || path.join(os.homedir(), ".local/state"),
        "agent-house",
      ),
  );
  fs.mkdirSync(directory, { recursive: true, mode: 0o700 });
  const filename = path.join(directory, "jobs.sqlite3");
  fs.closeSync(fs.openSync(filename, "a", 0o600));
  const db = new DatabaseSync(filename);
  db.exec(`PRAGMA busy_timeout=10000;
    CREATE TABLE IF NOT EXISTS occurrences(job TEXT, occurrence TEXT, fingerprint TEXT NOT NULL, status TEXT NOT NULL, result TEXT, PRIMARY KEY(job,occurrence));`);
  const fingerprint = createHash("sha256")
    .update(
      JSON.stringify({
        definition: loaded.hash,
        task,
        harness: options.harness || loaded.definition.default_harness,
        cwd: path.resolve(options.cwd || process.cwd()),
      }),
    )
    .digest("hex");
  try {
    db.exec("BEGIN IMMEDIATE");
    const existing = db
      .prepare("SELECT * FROM occurrences WHERE job=? AND occurrence=?")
      .get(options.jobId, options.occurrence);
    if (existing) {
      db.exec("ROLLBACK");
      if (existing.fingerprint !== fingerprint)
        throw Error("Occurrence already exists with different input");
      if (existing.status === "running")
        throw Error(
          "Occurrence is running or interrupted; inspect run records before creating a new occurrence",
        );
      return { ...JSON.parse(existing.result), replayed: true };
    }
    if (
      db
        .prepare("SELECT 1 FROM occurrences WHERE job=? AND status='running'")
        .get(options.jobId)
    ) {
      db.exec("ROLLBACK");
      throw Error(
        "Another occurrence is running or interrupted; overlapping job execution refused",
      );
    }
    db.prepare("INSERT INTO occurrences VALUES (?,?,?,'running',NULL)").run(
      options.jobId,
      options.occurrence,
      fingerprint,
    );
    db.exec("COMMIT");
    const result = await (options.execute || runAgent)(loaded, task, options);
    db.prepare(
      "UPDATE occurrences SET status=?,result=? WHERE job=? AND occurrence=?",
    ).run(
      result.status,
      JSON.stringify(result),
      options.jobId,
      options.occurrence,
    );
    return { ...result, replayed: false };
  } finally {
    db.close();
  }
}
