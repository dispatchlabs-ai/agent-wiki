import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";
import { randomUUID, createHash } from "node:crypto";
import { connectAgent } from "./vendor/wiki-client.mjs";
import { startBridge } from "./bridge.mjs";
import { resolveRuntime } from "./definition.mjs";
import { alternateHarness, observeAlternate } from "./harnesses.mjs";

export function codexArgs(definition, bridgeFile, cwd) {
  return [
    "exec",
    "--ignore-user-config",
    "--ignore-rules",
    "--json",
    "--color",
    "never",
    "--skip-git-repo-check",
    "-C",
    cwd,
    "--sandbox",
    "read-only",
    "-m",
    definition.runtime.model,
    "-c",
    'approval_policy="never"',
    "-c",
    `model_reasoning_effort=${JSON.stringify(definition.runtime.thinking)}`,
    "-c",
    `developer_instructions=${JSON.stringify(definition.instructions)}`,
    "-c",
    "features.multi_agent=false",
    "-c",
    "features.apps=false",
    "-c",
    "features.hooks=false",
    "-c",
    `mcp_servers.agent_house.command=${JSON.stringify(process.execPath)}`,
    "-c",
    `mcp_servers.agent_house.args=${JSON.stringify([fileURLToPath(new URL("./mcp-stdio.mjs", import.meta.url)), bridgeFile])}`,
    "-c",
    "mcp_servers.agent_house.required=true",
    "-c",
    "mcp_servers.agent_house.startup_timeout_sec=30",
    "-c",
    'mcp_servers.agent_house.default_tools_approval_mode="approve"',
    "-c",
    "mcp_servers.agent_house.tool_timeout_sec=130",
    "-",
  ];
}

export async function runAgent(loaded, task, options = {}) {
  const { hash } = loaded;
  const definition = {
    ...loaded.definition,
    runtime: resolveRuntime(loaded.definition, options.harness),
  };
  const cwd = path.resolve(options.cwd || process.cwd());
  if (!fs.statSync(cwd).isDirectory())
    throw Error("Working directory must be a directory");
  const config = JSON.parse(fs.readFileSync(loaded.credentialFile, "utf8"));
  if (options.resourceProof) config.agentHouseProof = options.resourceProof;
  if (config.agent !== definition.principal)
    throw Error("Credential principal does not match definition");
  if (config.privateKeyEnv)
    throw Error(
      "First connector requires privateKeyFile; environment keys are not supported",
    );
  const root = path.resolve(
    options.stateDir ||
      path.join(
        process.env.XDG_STATE_HOME || path.join(os.homedir(), ".local/state"),
        "agent-house/runs",
      ),
  );
  fs.mkdirSync(root, { recursive: true, mode: 0o700 });
  const id = randomUUID();
  const directory = path.join(root, id);
  fs.mkdirSync(directory, { mode: 0o700 });
  const record = {
    version: 1,
    id,
    status: "starting",
    started_at: new Date().toISOString(),
    definition: {
      name: definition.name,
      sha256: hash,
      principal: definition.principal,
    },
    runtime: definition.runtime,
    cwd,
    task_sha256: createHash("sha256").update(task).digest("hex"),
    authority: options.attribution || null,
    wiki: null,
    native_thread_id: null,
    cleanup: "not_started",
    tool_failures: [],
    directory,
  };
  const save = () => {
    const temporary = path.join(directory, "run.json.tmp");
    fs.writeFileSync(temporary, JSON.stringify(record, null, 2) + "\n", {
      mode: 0o600,
    });
    fs.renameSync(temporary, path.join(directory, "run.json"));
  };
  save();
  let connection,
    bridge,
    child,
    hardKill,
    timedOut = false,
    interrupted = false;
  const stop = () => {
    if (!child?.pid) return;
    const kill = (signal) => {
      try {
        process.kill(-child.pid, signal);
      } catch {}
    };
    kill("SIGTERM");
    hardKill ||= setTimeout(() => kill("SIGKILL"), 3000);
  };
  const interrupt = () => {
    interrupted = true;
    stop();
  };
  process.on("SIGINT", interrupt);
  process.on("SIGTERM", interrupt);
  const timeout = setTimeout(
    () => {
      timedOut = true;
      stop();
    },
    (options.timeout || 300) * 1000,
  );
  const checkCancelled = () => {
    options.guard?.();
    if (timedOut || interrupted) throw Error("Execution cancelled");
  };
  const accessTimer = options.guard
    ? setInterval(() => {
        try {
          options.guard();
        } catch {
          interrupt();
        }
      }, 250)
    : null;
  try {
    checkCancelled();
    connection = await (options.connect || connectAgent)(config);
    const response = await connection.credential.fetch(
      connection.credential.origin + "/api/agent/run",
      {
        headers: {
          Authorization: `Bearer ${await connection.credential.token()}`,
        },
      },
    );
    if (!response.ok) throw Error("Unable to read authoritative wiki run");
    record.wiki = await response.json();
    if (
      record.wiki.agent !== definition.principal ||
      record.wiki.run !== connection.credential.run
    )
      throw Error("Wiki returned an inconsistent run identity");
    checkCancelled();
    bridge = await startBridge(connection, { guard: checkCancelled });
    const bridgeFile = path.join(directory, "bridge.json");
    fs.writeFileSync(bridgeFile, JSON.stringify(bridge.config), {
      mode: 0o600,
    });
    checkCancelled();
    record.status = "running";
    save();
    const events = fs.openSync(
      path.join(directory, "events.jsonl"),
      "wx",
      0o600,
    );
    const errors = fs.openSync(path.join(directory, "stderr.log"), "wx", 0o600);
    let pending = "",
      turnCompleted = false,
      turnFailed = false;
    const event = (line) => {
      try {
        const value = JSON.parse(line);
        if (definition.runtime.harness !== "codex") {
          const outcome = observeAlternate(
            definition.runtime.harness,
            value,
            record,
          );
          if (outcome === "completed") turnCompleted = true;
          if (outcome === "failed") turnFailed = true;
          return;
        }
        if (value.type === "thread.started")
          record.native_thread_id = value.thread_id;
        if (value.type === "turn.completed") {
          turnCompleted = true;
          record.usage = value.usage;
        }
        if (value.type === "turn.failed" || value.type === "error")
          turnFailed = true;
        if (
          value.type === "item.completed" &&
          value.item?.type === "agent_message"
        )
          record.result = value.item.text;
        if (
          value.type === "item.completed" &&
          value.item?.type === "mcp_tool_call" &&
          value.item.status === "failed"
        )
          record.tool_failures.push({
            server: value.item.server,
            tool: value.item.tool,
          });
      } catch {
        /* Keep native output even when an event is not recognized. */
      }
    };
    try {
      const native =
        definition.runtime.harness === "codex"
          ? {
              command: options.codexCommand || "codex",
              args: codexArgs(definition, bridgeFile, cwd),
            }
          : alternateHarness(definition, directory, bridgeFile);
      checkCancelled();
      const env = { ...process.env };
      delete env.AGENT_HOUSE_TOKEN;
      child = spawn(native.command, native.args, {
        env,
        cwd,
        detached: true,
        stdio: ["pipe", "pipe", errors],
      });
      child.stdout.setEncoding("utf8");
      child.stdout.on("data", (chunk) => {
        fs.writeSync(events, chunk);
        pending += chunk;
        let newline;
        while ((newline = pending.indexOf("\n")) !== -1) {
          event(pending.slice(0, newline));
          pending = pending.slice(newline + 1);
        }
      });
      child.stdin.on("error", () => {});
      child.stdin.end(task);
      const result = await new Promise((resolve, reject) => {
        child.once("error", reject);
        child.once("close", (code, signal) => resolve({ code, signal }));
      });
      if (pending) event(pending);
      record.native_exit_code = result.code;
      record.native_signal = result.signal;
      checkCancelled();
      if (result.code !== 0 || !turnCompleted || turnFailed)
        throw Error(
          "Native harness did not complete successfully; inspect the private run logs",
        );
      record.status = "succeeded";
    } finally {
      fs.closeSync(events);
      fs.closeSync(errors);
    }
  } catch (error) {
    record.status = timedOut
      ? "timed_out"
      : interrupted
        ? "cancelled"
        : "failed";
    record.error = error.message;
    if (error.wikiRun)
      record.wiki = { agent: definition.principal, run: error.wikiRun };
    if (error.wikiCleanup) record.cleanup = error.wikiCleanup;
  } finally {
    clearInterval(accessTimer);
    clearTimeout(timeout);
    clearTimeout(hardKill);
    // Kill any orphan MCP subprocesses after the native process exits.
    if (child?.pid) {
      try {
        process.kill(-child.pid, "SIGKILL");
      } catch {}
    }
    try {
      await bridge?.close();
    } catch {}
    fs.rmSync(path.join(directory, "bridge.json"), { force: true });
    if (connection) {
      try {
        record.cleanup = await connection.close();
      } catch {
        record.cleanup = "unconfirmed";
      }
    }
    if (record.cleanup === "unconfirmed" && record.status === "succeeded") {
      record.status = "failed";
      record.error = "Task completed, but wiki run closure was not confirmed";
    }
    process.off("SIGINT", interrupt);
    process.off("SIGTERM", interrupt);
    record.finished_at = new Date().toISOString();
    save();
  }
  return record;
}
