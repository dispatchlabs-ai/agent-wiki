import fs from "node:fs";

export default function attach(pi, filename) {
  const config = JSON.parse(fs.readFileSync(filename, "utf8"));
  let ready = false,
    instructions = "";
  const request = async (route, body, signal) => {
    const response = await fetch(config.url + route, {
      method: body ? "POST" : "GET",
      headers: {
        Authorization: `Bearer ${config.token}`,
        "Content-Type": "application/json",
      },
      ...(body ? { body: JSON.stringify(body) } : {}),
      redirect: "error",
      signal: signal || AbortSignal.timeout(125000),
    });
    if (!response.ok) throw Error("Agent House bridge unavailable");
    return response.json();
  };
  pi.on("session_start", async () => {
    const catalog = await request("/catalog");
    instructions = catalog.instructions;
    const names = [];
    for (const tool of catalog.tools) {
      const name = tool.name.replaceAll(".", "_");
      if (names.includes(name)) throw Error("Conflicting Pi tool names");
      names.push(name);
      pi.registerTool({
        name,
        label: tool.name,
        description: tool.description,
        parameters: tool.inputSchema,
        async execute(_id, params, signal) {
          const result = await request(
            "/call",
            { name: tool.name, arguments: params },
            signal,
          );
          if (result.isError) throw Error(JSON.stringify(result.content));
          return { content: result.content, details: {} };
        },
      });
    }
    pi.setActiveTools(names);
    ready = true;
  });
  pi.on("before_agent_start", async (event) => {
    if (!ready) throw Error("Required Agent House tools did not initialize");
    return { systemPrompt: event.systemPrompt + "\n\n" + instructions };
  });
}
