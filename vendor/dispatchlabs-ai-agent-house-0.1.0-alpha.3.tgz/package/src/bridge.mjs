import http from "node:http";
import { randomBytes, timingSafeEqual } from "node:crypto";
import { once } from "node:events";

// Process-local capability bridge. The harness never receives the signing key.
export async function startBridge(connection, { guard = () => {} } = {}) {
  const secret = randomBytes(32).toString("base64url");
  const expected = Buffer.from(`Bearer ${secret}`);
  const tools = [];
  let cursor;
  do {
    guard();
    const page = await connection.client.listTools(cursor ? { cursor } : {});
    tools.push(...page.tools);
    cursor = page.nextCursor;
  } while (cursor);
  const names = new Set(tools.map((tool) => tool.name));
  const server = http.createServer(async (req, res) => {
    const finish = (status, value) => {
      res.writeHead(status, {
        "Content-Type": "application/json",
        "Cache-Control": "no-store",
      });
      res.end(JSON.stringify(value));
    };
    const supplied = Buffer.from(req.headers.authorization || "");
    if (
      supplied.length !== expected.length ||
      !timingSafeEqual(supplied, expected)
    )
      return finish(401, { error: "Unauthorized" });
    try {
      guard();
      if (req.method === "GET" && req.url === "/catalog")
        return finish(200, {
          tools,
          instructions: connection.client.getInstructions() || "",
        });
      if (req.method !== "POST" || req.url !== "/call")
        return finish(404, { error: "Not found" });
      const chunks = [];
      let length = 0;
      for await (const chunk of req) {
        length += chunk.length;
        if (length > 1024 * 1024)
          return finish(413, { error: "Request too large" });
        chunks.push(chunk);
      }
      const call = JSON.parse(Buffer.concat(chunks).toString());
      if (!names.has(call.name)) return finish(400, { error: "Unknown tool" });
      guard();
      const result = await connection.client.callTool(
        { name: call.name, arguments: call.arguments || {} },
        { signal: AbortSignal.timeout(120000) },
      );
      guard();
      finish(200, result);
    } catch {
      finish(502, { error: "Wiki tool request failed" });
    }
  });
  server.requestTimeout = 130000;
  server.listen(0, "127.0.0.1");
  await once(server, "listening");
  return {
    config: { url: `http://127.0.0.1:${server.address().port}`, token: secret },
    close: async () => {
      server.closeAllConnections();
      await new Promise((resolve) => server.close(resolve));
    },
  };
}
