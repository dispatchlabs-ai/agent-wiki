import type { DatabaseSync } from "node:sqlite";
export interface IdentityControl {
  [key: string]: any;
  db: any;
  transaction<T>(fn: () => T): T;
}
export interface IdentityDefinition {
  instructions: string;
  tools: string[];
}
export class IdentityError extends Error {
  code: string;
  status: number;
  constructor(code: string, message: string, status?: number);
}
export class AgentIdentityStore {
  constructor(
    control: IdentityControl,
    options?: { now?: () => number; ErrorType?: typeof IdentityError },
  );
  control: IdentityControl;
  db: any;
  now: () => number;
  ErrorType: typeof IdentityError;
  fail(): never;
  text(value: unknown): string;
  onRevokeInvoke(agent: string, principal: string): void;
  onSuspend(agent: string): void;
  enrollDefinition(
    id: string,
    owner: string,
    name: string,
    definition: IdentityDefinition,
  ): { agent: string; changed: boolean };
  principal(id: string): any;
  human(id: string): any;
  record(actor: string, action: string, target: string): void;
  get(id: string): any;
  allowed(actor: string, agent: string, permission: string): boolean;
  require(actor: string, agent: string, permission: string): void;
  list(actor: string): any[];
  definition(value: IdentityDefinition): string;
  create(
    actor: string,
    input: { name: string; definition: IdentityDefinition },
  ): any;
  configure(
    actor: string,
    agent: string,
    definition: IdentityDefinition,
  ): { definition: string };
  permission(
    actor: string,
    agent: string,
    principal: string,
    permission: string,
    enabled: boolean,
  ): void;
  transfer(actor: string, agent: string, owner: string): void;
  suspend(actor: string, agent: string): void;
}
