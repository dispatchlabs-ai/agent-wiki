import { DatabaseSync } from "node:sqlite";
import { randomBytes, randomUUID, createHash } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { AgentIdentityStore, IdentityError } from "./identity.mjs";
import { validateHarnesses } from "./definition.mjs";

const fail = (code, message, status = 400) => {
  throw new IdentityError(code, message, status);
};
const canonical = (value) =>
  value && typeof value === "object" && !Array.isArray(value)
    ? Object.fromEntries(
        Object.keys(value)
          .sort()
          .map((key) => [key, canonical(value[key])]),
      )
    : Array.isArray(value)
      ? value.map(canonical)
      : value;
const hash = (value) => createHash("sha256").update(value).digest("hex");
function fields(value, allowed) {
  if (!value || typeof value !== "object" || Array.isArray(value))
    fail("INVALID_REQUEST", "Expected an object");
  for (const key of Object.keys(value))
    if (!allowed.includes(key))
      fail("INVALID_REQUEST", `Unsupported field: ${key}`);
}
function text(value, label) {
  if (typeof value !== "string" || !value.trim() || value.length > 200)
    fail(
      "INVALID_REQUEST",
      `${label} must be a nonempty string of at most 200 characters`,
    );
  return value;
}
class Definitions extends AgentIdentityStore {
  onRevokeInvoke(agent, principal) {
    this.db
      .prepare(
        "UPDATE executions SET revoked=1 WHERE agent=? AND initiator=? AND status='running'",
      )
      .run(agent, principal);
  }
  onSuspend(agent) {
    this.db
      .prepare(
        "UPDATE executions SET revoked=1 WHERE agent=? AND status='running'",
      )
      .run(agent);
  }
  definition(value) {
    fields(value, ["version", "instructions", "default_harness", "harnesses"]);
    if (
      typeof value.instructions !== "string" ||
      value.instructions.length > 20000
    )
      fail(
        "INVALID_DEFINITION",
        "Instructions are required and limited to 20000 characters",
      );
    try {
      if (value.version !== 2 || !value.instructions.trim())
        throw Error("Use definition version 2 with nonempty instructions");
      validateHarnesses(value);
    } catch (e) {
      fail("INVALID_DEFINITION", e.message);
    }
    return JSON.stringify(value);
  }
}
export const authorityOperations = Object.freeze({
  "principal.create": {
    permission: "administrator",
    fields: ["name"],
    mutation: true,
  },
  "credential.issue": {
    permission: "administrator",
    fields: ["principal", "ttlSeconds", "agent"],
    mutation: true,
  },
  "credential.revoke": {
    permission: "administrator",
    fields: ["credential"],
    mutation: true,
  },
  "agent.create": {
    permission: "authenticated",
    fields: ["name", "definition"],
    mutation: true,
  },
  "agent.list": { permission: "authenticated", fields: [], mutation: false },
  "agent.get": {
    permission: "agent-access",
    fields: ["agent"],
    mutation: false,
  },
  "agent.configure": {
    permission: "configure",
    fields: ["agent", "expectedDefinition", "definition"],
    mutation: true,
  },
  "agent.permission": {
    permission: "manage-access",
    fields: ["agent", "principal", "permission", "enabled"],
    mutation: true,
  },
  "agent.suspend": {
    permission: "manage-access",
    fields: ["agent"],
    mutation: true,
  },
  "agent.authorize": {
    permission: "invoke",
    fields: ["agent"],
    mutation: false,
  },
});

// Independent state. No Agent Wiki database, login session or resource grants.
export class Authority {
  constructor(filename, { now = () => Date.now() } = {}) {
    this.now = now;
    if (filename !== ":memory:") {
      fs.mkdirSync(path.dirname(path.resolve(filename)), {
        recursive: true,
        mode: 0o700,
      });
      fs.closeSync(fs.openSync(filename, "a", 0o600));
      fs.chmodSync(filename, 0o600);
    }
    this.db = new DatabaseSync(filename);
    this.db
      .exec(`PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;
      CREATE TABLE IF NOT EXISTS principals(id TEXT PRIMARY KEY,kind TEXT NOT NULL CHECK(kind IN ('human','agent')),name TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1);
      CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,time TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,actor TEXT NOT NULL,action TEXT NOT NULL,target TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS administrators(principal TEXT PRIMARY KEY REFERENCES principals(id));
      CREATE TABLE IF NOT EXISTS credentials(id TEXT PRIMARY KEY,principal TEXT NOT NULL REFERENCES principals(id),digest TEXT UNIQUE NOT NULL,expires INTEGER NOT NULL,active INTEGER NOT NULL DEFAULT 1);
      CREATE TABLE IF NOT EXISTS operation_receipts(actor TEXT NOT NULL,request_id TEXT NOT NULL,fingerprint TEXT NOT NULL,result TEXT NOT NULL,PRIMARY KEY(actor,request_id));`);
    if (
      !this.db
        .prepare("PRAGMA table_info(credentials)")
        .all()
        .some((c) => c.name === "invoke_agent")
    )
      this.db.exec("ALTER TABLE credentials ADD COLUMN invoke_agent TEXT");
    for (const [column, type] of [
      ["previous_digest", "TEXT"],
      ["previous_expires", "INTEGER"],
    ])
      if (
        !this.db
          .prepare("PRAGMA table_info(credentials)")
          .all()
          .some((c) => c.name === column)
      )
        this.db.exec(`ALTER TABLE credentials ADD COLUMN ${column} ${type}`);
    this.depth = 0;
    this.agents = new Definitions(this, { now });
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS resource_capabilities(execution TEXT NOT NULL,audience TEXT NOT NULL,digest TEXT UNIQUE NOT NULL,expires INTEGER NOT NULL,PRIMARY KEY(execution,audience));
      CREATE TABLE IF NOT EXISTS execution_bindings(agent TEXT PRIMARY KEY REFERENCES agents(id), credential_file TEXT NOT NULL, cwd TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS executions(id TEXT PRIMARY KEY,agent TEXT NOT NULL REFERENCES agents(id),initiator TEXT NOT NULL REFERENCES principals(id),credential TEXT NOT NULL,definition TEXT NOT NULL REFERENCES agent_definitions(id),request_id TEXT NOT NULL,fingerprint TEXT NOT NULL,status TEXT NOT NULL,revoked INTEGER NOT NULL DEFAULT 0,result TEXT,created INTEGER NOT NULL,UNIQUE(initiator,request_id));
    `);
  }
  close() {
    this.db.close();
  }
  transaction(fn) {
    if (this.depth) return fn();
    this.db.exec("BEGIN IMMEDIATE");
    this.depth++;
    try {
      const result = fn();
      this.db.exec("COMMIT");
      return result;
    } catch (e) {
      this.db.exec("ROLLBACK");
      throw e;
    } finally {
      this.depth--;
    }
  }
  issue(principal, ttlSeconds, agent) {
    if (!Number.isInteger(ttlSeconds) || ttlSeconds < 1 || ttlSeconds > 2592000)
      fail(
        "INVALID_REQUEST",
        "ttlSeconds must be an integer from 1 to 2592000",
      );
    this.agents.human(principal);
    if (agent !== undefined) this.agents.require(principal, agent, "invoke");
    const id = randomUUID(),
      token = "ah_" + randomBytes(32).toString("base64url"),
      expires = this.now() + ttlSeconds * 1000;
    this.db
      .prepare(
        "INSERT INTO credentials(id,principal,digest,expires,invoke_agent) VALUES (?,?,?,?,?)",
      )
      .run(id, principal, hash(token), expires, agent ?? null);
    return {
      id,
      principal,
      token,
      expires,
      ...(agent ? { invoke_agent: agent } : {}),
    };
  }
  // Trusted local bootstrap only; deliberately not an HTTP operation.
  bootstrap(name, id = randomUUID()) {
    text(name, "name");
    return this.transaction(() => {
      if (this.db.prepare("SELECT 1 FROM principals").get())
        fail("ALREADY_INITIALIZED", "Authority is already initialized", 409);
      text(id, "principal");
      this.db
        .prepare("INSERT INTO principals(id,kind,name) VALUES (?,'human',?)")
        .run(id, name);
      this.db.prepare("INSERT INTO administrators VALUES (?)").run(id);
      const credential = this.issue(id, 2592000);
      this.agents.record(id, "authority:bootstrap", id);
      return credential;
    });
  }
  authenticate(token) {
    if (typeof token !== "string" || !/^ah_[A-Za-z0-9_-]{43}$/.test(token))
      fail("UNAUTHENTICATED", "Valid bearer credential required", 401);
    const found = this.db
      .prepare(
        "SELECT c.principal FROM credentials c JOIN principals p ON p.id=c.principal WHERE (c.digest=? OR (c.previous_digest=? AND c.previous_expires>?)) AND c.active=1 AND c.expires>? AND p.active=1",
      )
      .get(hash(token), hash(token), this.now(), this.now());
    if (!found)
      fail("UNAUTHENTICATED", "Valid bearer credential required", 401);
    return found.principal;
  }
  credentialScope(token, operation, agent) {
    this.authenticate(token);
    const scope = this.db
      .prepare(
        "SELECT invoke_agent FROM credentials WHERE digest=? OR previous_digest=?",
      )
      .get(hash(token), hash(token)).invoke_agent;
    if (
      scope &&
      (!["run.start", "run.get", "agent.authorize"].includes(operation) ||
        agent !== scope)
    )
      fail(
        "CREDENTIAL_SCOPE",
        "Credential permits invocation of its assigned agent only",
        403,
      );
  }
  authorize(actor, descriptor, input) {
    this.agents.human(actor);
    if (
      descriptor.permission === "administrator" &&
      !this.db
        .prepare("SELECT 1 FROM administrators WHERE principal=?")
        .get(actor)
    )
      fail("FORBIDDEN", "Administrator permission required", 403);
    if (descriptor.permission === "agent-access") {
      if (
        !["invoke", "configure", "manage-access"].some((p) =>
          this.agents.allowed(actor, input.agent, p),
        )
      )
        this.agents.fail();
    } else if (
      ["invoke", "configure", "manage-access"].includes(descriptor.permission)
    )
      this.agents.require(actor, input.agent, descriptor.permission);
  }
  execute(token, operation, input = {}, requestId) {
    return this.transaction(() => {
      const actor = this.authenticate(token);
      this.credentialScope(token, operation, input?.agent);
      if (!Object.hasOwn(authorityOperations, operation))
        fail("UNKNOWN_OPERATION", "Unknown operation", 404);
      const descriptor = authorityOperations[operation];
      fields(input, descriptor.fields);
      for (const key of descriptor.fields.filter(
        (k) => !["definition", "enabled", "ttlSeconds"].includes(k),
      ))
        if (!(
          operation === "credential.issue" &&
          key === "agent" &&
          input.agent === undefined
        ))
          text(input[key], key);
      this.authorize(actor, descriptor, input);
      const fingerprint = hash(JSON.stringify(canonical([operation, input])));
      if (descriptor.mutation) {
        text(requestId, "requestId");
        const receipt = this.db
          .prepare(
            "SELECT * FROM operation_receipts WHERE actor=? AND request_id=?",
          )
          .get(actor, requestId);
        if (receipt) {
          if (receipt.fingerprint !== fingerprint)
            fail(
              "IDEMPOTENCY_CONFLICT",
              "Request ID was already used with different input",
              409,
            );
          const result = JSON.parse(receipt.result);
          if (operation === "credential.issue")
            fail(
              "CREDENTIAL_ALREADY_ISSUED",
              `Credential ${result.id} was issued; its secret cannot be retrieved again`,
              409,
            );
          return result;
        }
      }
      let result;
      switch (operation) {
        case "principal.create": {
          const id = randomUUID();
          this.db
            .prepare(
              "INSERT INTO principals(id,kind,name) VALUES (?,'human',?)",
            )
            .run(id, input.name);
          this.agents.record(actor, operation, id);
          result = { id, name: input.name };
          break;
        }
        case "credential.issue":
          result = this.issue(input.principal, input.ttlSeconds, input.agent);
          this.agents.record(actor, operation, result.id);
          break;
        case "credential.revoke": {
          const updated = this.db
            .prepare("UPDATE credentials SET active=0 WHERE id=?")
            .run(input.credential);
          if (!updated.changes) this.agents.fail();
          this.agents.record(actor, operation, input.credential);
          result = { revoked: true };
          break;
        }
        case "agent.create":
          result = this.agents.create(actor, input);
          break;
        case "agent.list":
          result = this.agents.list(actor);
          break;
        case "agent.get": {
          const agent = this.agents.get(input.agent);
          result = {
            ...agent,
            configuration: JSON.parse(
              this.db
                .prepare("SELECT config FROM agent_definitions WHERE id=?")
                .get(agent.definition).config,
            ),
          };
          break;
        }
        case "agent.configure": {
          if (
            this.agents.get(input.agent).definition !== input.expectedDefinition
          )
            fail(
              "REVISION_CONFLICT",
              "Definition changed; read the current version",
              409,
            );
          result = this.agents.configure(actor, input.agent, input.definition);
          break;
        }
        case "agent.permission":
          this.agents.permission(
            actor,
            input.agent,
            input.principal,
            input.permission,
            input.enabled,
          );
          result = { updated: true };
          break;
        case "agent.suspend":
          this.agents.suspend(actor, input.agent);
          result = { suspended: true };
          break;
        case "agent.authorize":
          result = {
            allowed: true,
            agent: input.agent,
            initiator: actor,
            definition: this.agents.get(input.agent).definition,
          };
          break;
      }
      if (descriptor.mutation) {
        const stored =
          operation === "credential.issue"
            ? { ...result, token: undefined }
            : result;
        this.db
          .prepare("INSERT INTO operation_receipts VALUES (?,?,?,?)")
          .run(actor, requestId, fingerprint, JSON.stringify(stored));
      }
      return JSON.parse(JSON.stringify(result));
    });
  }
}
