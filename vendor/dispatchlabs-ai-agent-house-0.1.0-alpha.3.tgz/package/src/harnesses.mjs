import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

export function alternateHarness(definition, directory, bridgeFile) {
  const r = definition.runtime;
  if (r.harness === "claude") {
    const config = path.join(directory, "claude-mcp.json");
    fs.writeFileSync(
      config,
      JSON.stringify({
        mcpServers: {
          agent_house: {
            command: process.execPath,
            args: [
              fileURLToPath(new URL("./mcp-stdio.mjs", import.meta.url)),
              bridgeFile,
            ],
          },
        },
      }),
      { mode: 0o600 },
    );
    return {
      command: "claude",
      args: [
        "--print",
        "--verbose",
        "--output-format",
        "stream-json",
        "--model",
        r.model,
        "--effort",
        r.thinking,
        "--append-system-prompt",
        definition.instructions,
        "--strict-mcp-config",
        "--mcp-config",
        config,
        "--tools",
        "",
        "--allowedTools",
        "mcp__agent_house__*",
        "--permission-mode",
        "dontAsk",
        "--setting-sources",
        "",
        "--disable-slash-commands",
      ],
    };
  }
  if (r.harness === "pi") {
    const extension = path.join(directory, "pi-extension.mjs");
    fs.writeFileSync(
      extension,
      `import attach from ${JSON.stringify(new URL("./pi-extension.mjs", import.meta.url).href)};\nexport default pi => attach(pi, ${JSON.stringify(bridgeFile)});\n`,
      { mode: 0o600 },
    );
    return {
      command: "pi",
      args: [
        "--print",
        "--mode",
        "json",
        "--provider",
        r.provider,
        "--model",
        r.model,
        "--thinking",
        r.thinking,
        "--append-system-prompt",
        definition.instructions,
        "--no-extensions",
        "--extension",
        extension,
        "--no-builtin-tools",
        "--no-skills",
        "--no-prompt-templates",
        "--no-context-files",
        "--no-approve",
        "--session-dir",
        directory,
      ],
    };
  }
  throw Error("Unsupported harness");
}

export function observeAlternate(harness, value, record) {
  if (harness === "claude") {
    if (value.session_id) record.native_thread_id = value.session_id;
    if (value.type === "result") {
      record.result = value.result;
      record.usage = value.usage;
      record.native_models = value.modelUsage
        ? Object.keys(value.modelUsage)
        : [];
      return value.is_error || value.subtype !== "success"
        ? "failed"
        : "completed";
    }
  }
  if (harness === "pi") {
    if (value.type === "session") record.native_thread_id = value.id;
    if (value.type === "message_end" && value.message?.role === "assistant") {
      const m = value.message;
      record.result = m.content
        ?.filter((x) => x.type === "text")
        .map((x) => x.text)
        .join("\n");
      record.usage = m.usage;
      if (["error", "aborted"].includes(m.stopReason)) return "failed";
    }
    if (value.type === "agent_end") return "completed";
  }
}
