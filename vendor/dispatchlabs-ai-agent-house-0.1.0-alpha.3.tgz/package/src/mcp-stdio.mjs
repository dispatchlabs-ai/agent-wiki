import fs from "node:fs";
import { McpServer, fromJsonSchema } from "@modelcontextprotocol/server";
import { StdioServerTransport } from "@modelcontextprotocol/server/stdio";

const config = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
async function request(route, body) {
  const response = await fetch(config.url + route, {
    method: body ? "POST" : "GET",
    headers: {
      Authorization: `Bearer ${config.token}`,
      "Content-Type": "application/json",
    },
    ...(body ? { body: JSON.stringify(body) } : {}),
    redirect: "error",
    signal: AbortSignal.timeout(125000),
  });
  if (!response.ok) throw Error("Agent House bridge request failed");
  return response.json();
}
const catalog = await request("/catalog");
const server = new McpServer(
  { name: "agent-house-wiki", version: "0.1.0" },
  { instructions: catalog.instructions },
);
for (const tool of catalog.tools) {
  server.registerTool(
    tool.name,
    {
      description: tool.description,
      inputSchema: fromJsonSchema(tool.inputSchema),
      annotations: tool.annotations,
    },
    (args) => request("/call", { name: tool.name, arguments: args }),
  );
}
await server.connect(new StdioServerTransport());
