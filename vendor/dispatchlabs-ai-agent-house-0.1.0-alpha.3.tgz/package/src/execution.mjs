import fs from "node:fs";
import path from "node:path";
import { createHash, randomUUID, randomBytes } from "node:crypto";
import { IdentityError } from "./identity.mjs";
import { resolveRuntime } from "./definition.mjs";
import { runAgent } from "./run.mjs";
import { authorityOperations } from "./authority.mjs";

const fail = (code, message, status = 400) => {
  throw new IdentityError(code, message, status);
};
const digest = (value) => createHash("sha256").update(value).digest("hex");
export const executionOperations = Object.freeze({
  ...authorityOperations,
  "run.start": {
    permission: "invoke",
    fields: ["agent", "task", "harness", "job", "occurrence"],
    mutation: true,
  },
  "run.get": { permission: "invoke", fields: ["run"], mutation: false },
});

// Operator-only resource binding. Never accepts a path from an HTTP caller.
export function enrollExecution(authority, loaded, owner, cwd) {
  const { principal, name, version, instructions, default_harness, harnesses } =
    loaded.definition;
  const credential = JSON.parse(fs.readFileSync(loaded.credentialFile, "utf8"));
  if (credential.agent !== principal)
    fail("INVALID_BINDING", "Credential principal does not match agent");
  cwd = path.resolve(cwd);
  if (!fs.statSync(cwd).isDirectory())
    fail("INVALID_BINDING", "Working directory must exist");
  return authority.transaction(() => {
    const result = authority.agents.enrollDefinition(principal, owner, name, {
      version,
      instructions,
      default_harness,
      harnesses,
    });
    const prior = authority.db
      .prepare("SELECT * FROM execution_bindings WHERE agent=?")
      .get(principal);
    if (
      prior &&
      (prior.credential_file !== loaded.credentialFile || prior.cwd !== cwd)
    )
      fail("REGISTRATION_CONFLICT", "Existing execution binding differs", 409);
    authority.db
      .prepare("INSERT OR IGNORE INTO execution_bindings VALUES (?,?,?)")
      .run(principal, loaded.credentialFile, cwd);
    if (!prior)
      authority.agents.record("operator", "execution:bind", principal);
    return { ...result, changed: result.changed || !prior };
  });
}

export function createExecutionApplication(
  authority,
  { executeRun = runAgent, stateDir, timeout = 660 } = {},
) {
  const db = authority.db;
  db.exec(
    `CREATE TABLE IF NOT EXISTS execution_jobs(agent TEXT NOT NULL,job TEXT NOT NULL,occurrence TEXT NOT NULL,run TEXT NOT NULL REFERENCES executions(id),PRIMARY KEY(agent,job,occurrence));`,
  );
  const view = (row) => ({
    id: row.id,
    agent: row.agent,
    initiator: row.initiator,
    definition: row.definition,
    status: row.status,
    ...(row.result ? JSON.parse(row.result) : {}),
  });
  const guard = (token, id) => {
    const actor = authority.authenticate(token);
    const row = db.prepare("SELECT * FROM executions WHERE id=?").get(id);
    if (
      !row ||
      row.initiator !== actor ||
      row.revoked ||
      row.status !== "running"
    )
      fail("RUN_REVOKED", "Execution is no longer authorized", 403);
    authority.credentialScope(token, "run.start", row.agent);
    authority.agents.require(actor, row.agent, "invoke");
  };
  const application = {
    operations: executionOperations,
    authenticate: (token) => authority.authenticate(token),
    async execute(token, operation, input = {}, requestId) {
      if (typeof operation !== "string")
        fail("UNKNOWN_OPERATION", "Unknown operation", 404);
      if (!operation.startsWith("run."))
        return authority.execute(token, operation, input, requestId);
      const actor = authority.authenticate(token);
      if (!Object.hasOwn(executionOperations, operation))
        fail("UNKNOWN_OPERATION", "Unknown operation", 404);
      if (
        !input ||
        typeof input !== "object" ||
        Array.isArray(input) ||
        Object.keys(input).some(
          (k) => !executionOperations[operation].fields.includes(k),
        )
      )
        fail("INVALID_REQUEST", "Unsupported execution input");
      if (operation === "run.get") {
        if (typeof input.run !== "string")
          fail("INVALID_REQUEST", "Run ID required");
        const row = db
          .prepare("SELECT * FROM executions WHERE id=?")
          .get(input.run);
        if (!row) fail("NOT_FOUND", "Not found", 404);
        authority.credentialScope(token, "run.get", row.agent);
        authority.agents.require(actor, row.agent, "invoke");
        // An invoker may read its own runs; the owner may inspect all runs.
        if (
          row.initiator !== actor &&
          authority.agents.get(row.agent).owner !== actor
        )
          fail("NOT_FOUND", "Not found", 404);
        return view(row);
      }
      if (
        typeof input.agent !== "string" ||
        typeof input.task !== "string" ||
        !input.task.trim() ||
        input.task.length > 20000 ||
        typeof requestId !== "string" ||
        !requestId.trim() ||
        requestId.length > 200
      )
        fail(
          "INVALID_REQUEST",
          "Agent, task (up to 20000 characters), and request ID required",
        );
      if (
        (input.job === undefined) !== (input.occurrence === undefined) ||
        [input.job, input.occurrence].some(
          (v) =>
            v !== undefined &&
            (typeof v !== "string" || !v.trim() || v.length > 200),
        )
      )
        fail(
          "INVALID_REQUEST",
          "Job and occurrence must both be nonempty strings of at most 200 characters",
        );
      authority.credentialScope(token, operation, input.agent);
      let admitted = false;
      const row = authority.transaction(() => {
        authority.credentialScope(token, operation, input.agent);
        authority.agents.require(actor, input.agent, "invoke");
        const agent = authority.agents.get(input.agent);
        const config = JSON.parse(
          db
            .prepare("SELECT config FROM agent_definitions WHERE id=?")
            .get(agent.definition).config,
        );
        const fingerprint = digest(
          JSON.stringify([
            input.agent,
            input.task,
            input.harness ?? null,
            input.job ?? null,
            input.occurrence ?? null,
          ]),
        );
        const previous = db
          .prepare(
            "SELECT * FROM executions WHERE initiator=? AND request_id=?",
          )
          .get(actor, requestId);
        if (previous) {
          if (previous.fingerprint !== fingerprint)
            fail(
              "IDEMPOTENCY_CONFLICT",
              "Request ID was already used with different input",
              409,
            );
          return previous;
        }
        try {
          resolveRuntime(config, input.harness);
        } catch {
          fail("INVALID_REQUEST", "Harness is not configured");
        }
        if (
          !db
            .prepare("SELECT 1 FROM execution_bindings WHERE agent=?")
            .get(input.agent)
        )
          fail(
            "NO_EXECUTION_BINDING",
            "An operator must register resource access before execution",
            409,
          );
        if (input.job !== undefined) {
          if (
            db
              .prepare(
                "SELECT 1 FROM execution_jobs WHERE agent=? AND job=? AND occurrence=?",
              )
              .get(input.agent, input.job, input.occurrence)
          )
            fail(
              "OCCURRENCE_EXISTS",
              "This job occurrence is already admitted",
              409,
            );
          if (
            db
              .prepare(
                "SELECT 1 FROM execution_jobs j JOIN executions e ON e.id=j.run WHERE j.agent=? AND j.job=? AND e.status='running'",
              )
              .get(input.agent, input.job)
          )
            fail(
              "JOB_RUNNING",
              "An earlier job occurrence is running or requires recovery",
              409,
            );
        }
        const id = randomUUID();
        const credential = db
          .prepare(
            "SELECT id FROM credentials WHERE digest=? OR previous_digest=?",
          )
          .get(digest(token), digest(token)).id;
        db.prepare(
          "INSERT INTO executions(id,agent,initiator,credential,definition,request_id,fingerprint,status,created) VALUES (?,?,?,?,?,?,?,'running',?)",
        ).run(
          id,
          input.agent,
          actor,
          credential,
          agent.definition,
          requestId,
          fingerprint,
          authority.now(),
        );
        if (input.job !== undefined)
          db.prepare("INSERT INTO execution_jobs VALUES (?,?,?,?)").run(
            input.agent,
            input.job,
            input.occurrence,
            id,
          );
        authority.agents.record(actor, "run:admit", id);
        admitted = true;
        return db.prepare("SELECT * FROM executions WHERE id=?").get(id);
      });
      if (!admitted) return { ...view(row), replayed: true };
      const agent = authority.agents.get(row.agent);
      const config = JSON.parse(
        db
          .prepare("SELECT config FROM agent_definitions WHERE id=?")
          .get(row.definition).config,
      );
      const binding = db
        .prepare("SELECT * FROM execution_bindings WHERE agent=?")
        .get(row.agent);
      const attribution = {
        run: row.id,
        agent: row.agent,
        initiator: row.initiator,
        definition: row.definition,
        credential: row.credential,
      };
      let result;
      try {
        guard(token, row.id);
        const resource = JSON.parse(
          fs.readFileSync(binding.credential_file, "utf8"),
        );
        const proof = randomBytes(32).toString("base64url");
        db.prepare("INSERT INTO resource_capabilities VALUES (?,?,?,?)").run(
          row.id,
          resource.endpoint,
          digest(proof),
          authority.now() + timeout * 1000,
        );
        const record = await executeRun(
          {
            definition: { ...config, name: agent.name, principal: row.agent },
            hash: digest(JSON.stringify(config)),
            credentialFile: binding.credential_file,
          },
          input.task,
          {
            cwd: binding.cwd,
            stateDir,
            timeout,
            harness: input.harness,
            attribution,
            resourceProof: proof,
            guard: () => guard(token, row.id),
          },
        );
        result = {
          status: record.status,
          native_run_id: record.id,
          native_thread_id: record.native_thread_id,
          wiki: record.wiki,
          cleanup: record.cleanup,
          result: record.result,
        };
        try {
          guard(token, row.id);
        } catch {
          result.status = "cancelled";
          result.result = undefined;
        }
      } catch {
        result = {
          status: "failed",
          error: "Execution failed; inspect the private host logs",
        };
      }
      authority.transaction(() => {
        try {
          guard(token, row.id);
        } catch {
          result.status = "cancelled";
          delete result.result;
        }
        db.prepare("UPDATE executions SET status=?,result=? WHERE id=?").run(
          result.status,
          JSON.stringify(result),
          row.id,
        );
        authority.agents.record(actor, "run:" + result.status, row.id);
      });
      // Never disclose a result after the caller credential or invoke grant was revoked.
      authority.authenticate(token);
      authority.agents.require(actor, row.agent, "invoke");
      return view(
        db.prepare("SELECT * FROM executions WHERE id=?").get(row.id),
      );
    },
  };
  let active = 0;
  const waiters = [];
  return {
    ...application,
    async execute(...args) {
      active++;
      try {
        return await application.execute(...args);
      } finally {
        active--;
        if (!active) for (const resolve of waiters.splice(0)) resolve();
      }
    },
    waitForIdle: () =>
      active
        ? new Promise((resolve) => waiters.push(resolve))
        : Promise.resolve(),
  };
}
