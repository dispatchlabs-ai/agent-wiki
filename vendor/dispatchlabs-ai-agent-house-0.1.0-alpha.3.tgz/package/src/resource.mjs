import { DatabaseSync } from "node:sqlite";
import { createHash } from "node:crypto";
import { IdentityError } from "./identity.mjs";

const deny = () => {
  throw new IdentityError(
    "RESOURCE_DENIED",
    "Execution is not authorized for this resource",
    403,
  );
};
// Same-host resource adapter. Opens authority state read-only and never caches a decision.
export function authorizeResource(
  database,
  { agent, audience, proof, execution },
  now = Date.now(),
) {
  let db;
  try {
    db = new DatabaseSync(database, { readOnly: true });
    db.exec("PRAGMA busy_timeout=1000");
    if (
      proof !== undefined &&
      (typeof proof !== "string" || !/^[A-Za-z0-9_-]{43}$/.test(proof))
    )
      deny();
    const row =
      proof !== undefined
        ? db
            .prepare("SELECT * FROM resource_capabilities WHERE digest=?")
            .get(createHash("sha256").update(proof).digest("hex"))
        : db
            .prepare(
              "SELECT * FROM resource_capabilities WHERE execution=? AND audience=?",
            )
            .get(execution, audience);
    if (!row || row.audience !== audience || row.expires <= now) deny();
    const run = db
      .prepare(
        "SELECT e.*,c.active credential_active,c.expires credential_expires,p.active initiator_active,a.owner,g.active agent_active FROM executions e JOIN credentials c ON c.id=e.credential JOIN principals p ON p.id=e.initiator JOIN agents a ON a.id=e.agent JOIN principals g ON g.id=e.agent WHERE e.id=?",
      )
      .get(row.execution);
    if (
      !run ||
      run.agent !== agent ||
      run.status !== "running" ||
      run.revoked ||
      !run.credential_active ||
      run.credential_expires <= now ||
      !run.initiator_active ||
      !run.agent_active
    )
      deny();
    if (
      run.owner !== run.initiator &&
      !db
        .prepare(
          "SELECT 1 FROM agent_permissions WHERE agent=? AND principal=? AND permission='invoke'",
        )
        .get(agent, run.initiator)
    )
      deny();
    return {
      execution: run.id,
      agent,
      initiator: run.initiator,
      definition: run.definition,
    };
  } catch {
    deny();
  } finally {
    db?.close();
  }
}
